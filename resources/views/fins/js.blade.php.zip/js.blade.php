@if(Request::segment(1) == 'golongan')
<script>
    function konfir() {
        if ($('#acc_up').val() == 0) {
            var tanya = confirm("Anda sudah melakukan perubahan berdasarkan persentase, aksi ini akan menghapus semua perubahan persentase yang telah dilakukan !!!");
        }
    }

    $(document).ready(function() {
        $('#user_table').DataTable({
            //   processing: true,
            //   responsive: true,
            scrollX: true,
            language: {
                paginate: {
                    next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
                    previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>'
                }
            },
            serverSide: true,
            ajax: {
                url: "golongan",
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: false,
                    searchable: false
                },
                {
                    data: 'golongan',
                    name: 'golongan'
                },
                {
                    data: 'kenaikan',
                    name: 'kenaikan'
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false
                }
            ]
        });

        $('#sample_form').on('submit', function(event) {
            event.preventDefault();

            $.ajax({
                url: "golongan/update",
                method: "POST",
                data: $(this).serialize(),
                dataType: "json",
                beforeSend: konfir(),
                success: function(data) {
                    var html = '';
                    if (data.errors) {
                        html = '<div class="alert alert-danger">';
                        for (var count = 0; count < data.errors.length; count++) {
                            html += '<p>' + data.errors[count] + '</p>';
                        }
                        html += '</div>';
                    }
                    if (data.success) {
                        html = '<div class="alert alert-success">' + data.success + '</div>';
                        $('#sample_form')[0].reset();
                        $('#user_table').DataTable().ajax.reload();
                        $('#exampleModal').hide();
                        $('.modal-backdrop').remove();
                    }
                    toastr.success('Berhasil')
                }
            });
        });

        $(document).on('click', '.edit', function() {
            var id = $(this).attr('id');
            $('#form_result').html('');

            $.ajax({
                url: "golongan/edit/" + id,
                dataType: "json",
                success: function(data) {
                    $('#kenaikan').val(data.result.kenaikan);
                    $('#action').val('edit');
                    $('#hidden_id').val(id);
                }
            })
        });

    });
</script>
@endif

@if(Request::segment(1) == 'gaji-pokok')
<script>
    $(document).ready(function() {
        $('#user_table').DataTable({
            //   processing: true,
            // responsive: true,
            language: {
                paginate: {
                    next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
                    previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>'
                }
            },
            scrollX: true,
            serverSide: true,
            ajax: {
                url: "gaji-pokok",
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: false,
                    searchable: false
                },
                {
                    data: 'th',
                    name: 'th'
                },
                {
                    data: 'IA',
                    name: 'IA'
                },
                {
                    data: 'IB',
                    name: 'IB'
                },
                {
                    data: 'IC',
                    name: 'IC'
                },
                {
                    data: 'ID',
                    name: 'ID'
                },
                {
                    data: 'IIA',
                    name: 'IIA'
                },
                {
                    data: 'IIB',
                    name: 'IIB'
                },
                {
                    data: 'IIC',
                    name: 'IIC'
                },
                {
                    data: 'IID',
                    name: 'IID'
                },
                {
                    data: 'IIE',
                    name: 'IIE'
                },
                {
                    data: 'IIIA',
                    name: 'IIIA'
                },
                {
                    data: 'IIIB',
                    name: 'IIIB'
                },
                {
                    data: 'IIIC',
                    name: 'IIIC'
                },
                {
                    data: 'IIID',
                    name: 'IIID'
                }
                //   {
                //     data: 'IVA',
                //     name: 'IVA'
                //   },
                //   {
                //     data: 'IVB',
                //     name: 'IVB'
                //   },
                //   {
                //     data: 'IVC',
                //     name: 'IVC'
                //   },
                //   {
                //     data: 'IVD',
                //     name: 'IVD'
                //   },
                //   {
                //     data: 'IVE',
                //     name: 'IVE'
                //   }
                //   {
                //     data: 'action',
                //     name: 'action',
                //     orderable: false
                //   }
            ]
        });

        $.ajax({
            url: "getgapok",
            dataType: "json",
            success: function(data) {
                $('#acc_up').val(data.acc_up);
            }
        })
    });

    $('#sample_form').on('submit', function(event) {
        event.preventDefault();

        if ($('#konfirm').val() == 'YA') {
            $.ajax({
                url: "intahun",
                method: "POST",
                data: $(this).serialize(),
                dataType: "json",
                success: function(data) {
                    var html = '';
                    if (data.errors) {
                        html = '<div class="alert alert-danger">';
                        for (var count = 0; count < data.errors.length; count++) {
                            html += '<p>' + data.errors[count] + '</p>';
                        }
                        html += '</div>';
                    }
                    if (data.success) {
                        html = '<div class="alert alert-success">' + data.success + '</div>';
                        $('#acc_up').val(1);
                        $('#sample_form')[0].reset();
                        $('#user_table').DataTable().ajax.reload();
                        $('#exampleModal').hide();
                        $('.modal-backdrop').remove();
                    }
                    toastr.success('Berhasil')
                }
            });
        } else {
            $('#sample_form')[0].reset();
            $('#user_table').DataTable().ajax.reload();
            $('#exampleModal').hide();
            $('.modal-backdrop').remove();
            toastr.info('Proses Dibatalkan')
        }
    });

    $(document).on('click', '.naik', function() {
        $('#label_persen').html('Masukan Persentase Kenaikan');
        $('#action').val('naik');
    });

    $(document).on('click', '.turun', function() {
        $('#label_persen').html('Masukan Persentase Penurunan');
        $('#action').val('turun');
    });

    $(document).on('click', '.edit', function() {

        $.ajax({
            url: "getgapok",
            dataType: "json",
            success: function(data) {
                $('#IA').val(data.IA);
                $('#IB').val(data.IB);
                $('#IC').val(data.IC);
                $('#ID').val(data.ID);
                $('#IIA').val(data.IIA);
                $('#IIB').val(data.IIB);
                $('#IIC').val(data.IIC);
                $('#IID').val(data.IID);
                $('#IIE').val(data.IIE);
                $('#IIIA').val(data.IIIA);
                $('#IIIB').val(data.IIIB);
                $('#IIIC').val(data.IIIC);
                $('#IIID').val(data.IIID);
                // $('#IVA').val(data.IVA);
                // $('#IVB').val(data.IVB);
                // $('#IVC').val(data.IVC);
                // $('#IVD').val(data.IVD);
                // $('#IVE').val(data.IVE);
            }
        })
    });

    $('#form_edit').on('submit', function(event) {
        event.preventDefault();

        if ($('#konfirm').val() == 'YA') {
            $.ajax({
                url: "upgapok",
                method: "POST",
                data: $(this).serialize(),
                dataType: "json",
                success: function(data) {
                    var html = '';
                    if (data.errors) {
                        html = '<div class="alert alert-danger">';
                        for (var count = 0; count < data.errors.length; count++) {
                            html += '<p>' + data.errors[count] + '</p>';
                        }
                        html += '</div>';
                    }
                    if (data.success) {
                        html = '<div class="alert alert-success">' + data.success + '</div>';
                        $('#acc_up').val(1);
                        $('#form_edit')[0].reset();
                        $('#user_table').DataTable().ajax.reload();
                        $('#ModalEdit').hide();
                        $('.modal-backdrop').remove();
                    }
                    toastr.success('Berhasil')
                }
            });
        } else {
            $('#form_edit')[0].reset();
            $('#user_table').DataTable().ajax.reload();
            $('#ModalEdit').hide();
            $('.modal-backdrop').remove();
            toastr.info('Proses Dibatalkan')
        }
    });

    $('#form_persen').on('submit', function(event) {
        event.preventDefault();

        var action_url = '';

        if ($('#action').val() == 'naik') {
            action_url = "naikper";
        }

        if ($('#action').val() == 'turun') {
            action_url = "turunper";
        }

        if ($('#konfirm').val() == 'YA') {
            $.ajax({
                url: action_url,
                method: "POST",
                data: $(this).serialize(),
                dataType: "json",
                success: function(data) {
                    var html = '';
                    if (data.errors) {
                        html = '<div class="alert alert-danger">';
                        for (var count = 0; count < data.errors.length; count++) {
                            html += '<p>' + data.errors[count] + '</p>';
                        }
                        html += '</div>';
                    }
                    if (data.success) {
                        html = '<div class="alert alert-success">' + data.success + '</div>';
                        $('#acc_up').val(0);
                        $('#form_persen')[0].reset();
                        $('#user_table').DataTable().ajax.reload();
                        $('#ModalPersen').hide();
                        $('.modal-backdrop').remove();
                    }
                    toastr.success('Berhasil')
                }
            });
        } else {
            $('#form_persen')[0].reset();
            $('#user_table').DataTable().ajax.reload();
            $('#ModalPersen').hide();
            $('.modal-backdrop').remove();
            toastr.info('Proses Dibatalkan')
        }
    });

    function konfir() {
        if ($('#acc_up').val() == 1) {
            var tanya = confirm("Apakah anda sudah melakukan setting kenaikan pergolongan ?");

            if (tanya === true) {
                $('#konfirm').val('YA');
            } else {
                $('#konfirm').val('TIDAK');
            }
        } else {
            var tanya = confirm("Anda sudah melakukan perubahan berdasarkan persentase, aksi ini akan menghapus semua perubahan persentase yang telah dilakukan !!!");

            if (tanya === true) {
                var tanya2 = confirm("Apakah anda sudah melakukan setting kenaikan pergolongan ?");

                if (tanya2 === true) {
                    $('#konfirm').val('YA');
                } else {
                    $('#konfirm').val('TIDAK');
                }
            } else {
                $('#konfirm').val('TIDAK');
            }
        }
    }

    function konfir_persen() {
        var tanya = confirm("Aksi ini akan berpengaruh pada semua nominal gaji pokok, anda yakin akan melanjutkannya ?");

        if (tanya === true) {
            $('#konfirm').val('YA');
        } else {
            $('#konfirm').val('TIDAK');
        }
    }
</script>
@endif

@if(Request::segment(1) == 'gaji-karyawan')
<script>
    $(document).ready(function() {

        $('#bln').datepicker({
            format: "mm-yyyy",
            viewMode: "months",
            minViewMode: "months",
            autoclose: true
        });
        
        $('.daterange').datepicker({
            format: "mm-yyyy",
            viewMode: "months",
            minViewMode: "months",
            autoclose: true
        }).on('changeDate', function(ev){
            var tgl = $(this).val();
            $.ajax({
                url: "cekdata",
                method: "GET",
                data: {
                    tgl: tgl
                },
                
                success: function(data) {
                    if(data.length > 0){
                        toastr.success('data ada');
                        document.getElementById("ezz").disabled = false;
                    }else{
                        toastr.warning('data tidak ditemukan');
                        document.getElementById("ezz").disabled = true;
                    }
                }
            })
        });
        
        $('.cobain').datepicker({
            format: "mm-yyyy",
            viewMode: "months",
            minViewMode: "months",
            autoclose: true
        });

        load_data();

        function load_data() {
            var bln = $('#bln').val();
            var kan = $('#kan').val();
            var jab = $('#jab').val();
            console.log(bln);
            $('#user_table').DataTable({
                //   processing: true,
                // responsive: true,
                //   scrollCollapse: true,
                //   paging:         false,
                language: {
                    paginate: {
                        next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
                        previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>'
                    }
                },
                scrollX: true,
                serverSide: true,
                ajax: {
                    url: "gaji-karyawan",
                    data: {
                        bln: bln,
                        kan: kan,
                        jab: jab
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'tgl',
                        name: 'tgl'
                    },
                    {
                        data: 'nama',
                        name: 'nama'
                    },
                    {
                        data: 'jabatan',
                        name: 'jabatan'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'gajpok',
                        name: 'gajpok'
                    },
                    {
                        data: 'tjjabatan',
                        name: 'tjjabatan'
                    },
                    {
                        data: 'tjd',
                        name: 'tjd'
                    },
                    {
                        data: 'tja',
                        name: 'tja'
                    },
                    {
                        data: 'tjp',
                        name: 'tjp'
                    },
                    {
                        data: 'tjberas',
                        name: 'tjberas'
                    },
                    {
                        data: 'tp',
                        name: 'tp'
                    },
                    {
                        data: 'jml_hari',
                        name: 'jml_hari'
                    },
                    {
                        data: 'tot',
                        name: 'tot'
                    },
                ],
            });
        }

        $('.cek').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.cek1').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.cek2').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.reset').on('click', function() {
            $('#user_table').DataTable().destroy();
            load_data();
            $('#kan,#jab,#bln').val('');
        });
        
        // $('#tgl').on('change', function(){
        //     $.ajax({
        //         url: "cekdata",
        //         method: "GET",
        //         data: {
        //                 unit: unit,
        //                 status: status,
        //                 tgl: tgl
        //         },
                
        //         success: function(data) {
        //             if(data.length > 0){
        //                 toastr.success('ada');
        //             }else{
        //                 toastr.warning('tidak ada');
        //             }
        //         }
        //     });
        // })
    });
</script>
@endif

@if(Request::segment(1) == 'pengeluaran' || Request::segment(2) == 'pengeluaran')
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="application/javascript">
    function rupiah(objek) {
        separator = ".";
        a = objek.value;
        b = a.replace(/[^\d]/g, "");
        c = "";
        panjang = b.length;
        j = 0;
        for (i = panjang; i > 0; i--) {
            j = j + 1;
            if (((j % 3) == 1) && (j != 1)) {
                c = b.substr(i - 1, 1) + separator + c;
            } else {
                c = b.substr(i - 1, 1) + c;
            }
        }
        if (c <= 0) {
            objek.value = '';
        } else {
            objek.value = c;
        }

        var input = document.getElementById("nominal").value.replace(/\./g, "");
        console.log(a)

    }
    
    function encodeImageFileAsURL(element) {
        var file = element.files[0];
        //   console.log(file.name);
        var reader = new FileReader();
        reader.onloadend = function() {
            console.log('RESULT', reader.result)
            $('#base64').val(reader.result);
            $('#nama_file').val(file.name);
        }
        reader.readAsDataURL(file);
    }

    $(document).ready(function() {
        
        var keuangan = '<?= Auth::user()->keuangan ?>'
        var level = '<?= Auth::user()->level ?>'

        $('#user_table').on('dblclick', 'tr', function(){
            var oTable = $('#user_table'). dataTable();
            var oData = oTable.fnGetData(this);
            var id = oData.id;
            
            $('#modals').modal('show');
            var body = '';
            var footer = '';
            
            $.ajax({
                url: "pengeluaranBy/" + id,
                dataType: "json",
                success: function(response) {
                    // console.log(response)
                    var data = response.ui
                    if(data.bukti != null){
                        var bukti = `<a href="https://kilauindonesia.org/kilau/bukti/` + data.bukti + `" class="btn btn-primary btn-xxs" target="_blank">Lihat Foto</a>`;
                    }else{
                        var bukti = `<span class="badge badge-primary badge-xxs light" disabled>Lihat Foto</span>`;
                    }
                    
                    if(data.acc == 0){
                        var tolak = `<div class="mb-3 row">
                                <label class="col-sm-4 ">Note</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+data.note+`</text>
                                </div>
                            </div>`;
                    }else{
                        var tolak = ``;
                    }
                    
                    if(data.user_approve != null){
                           var con = `<div class="mb-3 row">
                                    <label class="col-sm-4 ">User Confirm</label>
                                    <label class="col-sm-1 ">:</label>
                                    <div class="col-sm-6">
                                       <text>`+response.ua.name+`</text>
                                    </div>
                                </div>`
                        }else{
                            var con = ``;
                    }
                    
                    var number_string = data.nominal.toString(),
                        sisa = number_string.length % 3,
                        rupiah = number_string.substr(0, sisa),
                        ribuan = number_string.substr(sisa).match(/\d{3}/g);

                    if (ribuan) {
                        separator = sisa ? '.' : '';
                        rupiah += separator + ribuan.join('.');
                    }
                    
                    body = `<div class="mb-3 row">
                                <label class="col-sm-4 ">Tanggal</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+data.tgl+`</text>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">User Input</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+data.name+`</text>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">Jenis Transaksi</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+data.jenis_transaksi+`</text>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">Nominal</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                    <div style="display: block" id="nom_hide">
                                        <text>`+rupiah+`</text>
                                   </div>
                                   <div style="display: none" id="input_hide">
                                        <input class="form-control" id="ednom" name="ednom" placeholder="`+data.nominal+`"/>
                                   </div>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">Keterangan</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                    <div style="display: block" id="ket_hide">
                                       <text>`+data.keterangan+`</text>
                                    </div>
                                    <div style="display: none" id="text_hide">
                                       <textarea id="edket" name="edket" class="form-control" height="150px">`+data.keterangan+`</textarea>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">Bukti</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+bukti+`</text>
                                </div>
                            </div>
                            ` + tolak + con;
                            
                    if(keuangan == 'admin' || keuangan == 'kacab' || keuangan == 'keuangan pusat'){
                        if (data.acc == 0) {
                            var footer = ``
                        } else if (data.acc == 1) {
                            var footer = `
                            <a href="javascript:void(0)" class="btn btn-danger rejej" id="` + data.id + `" data="reject" data-bs-toggle="modal" data-bs-target="#modal-reject" data-bs-dismiss="modal">Reject</a>`
                        } else if (data.acc == 2) {
                            var footer = `
                            <div style="display: block" id="foot_hide">
                                <a href="javascript:void(0)" class="btn btn-info editod" id="` + data.id + `" >Edit</a>
                                <button type="button" class="btn btn-success aksi" id="` + data.id + `" data="acc" type="submit">Approve</button>
                                <a href="javascript:void(0)" class="btn btn-danger rejej" id="` + data.id + `" data="reject" data-bs-toggle="modal" data-bs-target="#modal-reject" data-bs-dismiss="modal">Reject</a>
                            </div>
                            <div style="display: none" id="submit_hide">
                                <a href="javascript:void(0)" class="btn btn-danger gagal" id="` + data.id + `" >Batal</a>
                                <button type="button" class="btn btn-success cok" id="` + data.id + `"  type="submit">Simpan</button>
                            </div>
                            `
                        } else {
                            var footer = ``;
                        }
                    }else{
                        if(data.acc == 2){
                            var footer = `<div style="display: block" id="foot_hide">
                                <a href="javascript:void(0)" class="btn btn-info editod" id="` + data.id + `">Edit</a>
                            </div>
                            <div style="display: none" id="submit_hide">
                                <a href="javascript:void(0)" class="btn btn-danger gagal" id="` + data.id + `" >Batal</a>
                                <button type="button" class="btn btn-success cok" id="` + data.id + `"  type="submit">Simpan</button>
                            </div>
                            `   
                        }
                    }
                    
                    
                    $('#boday').html(body)
                    $('#footay').html(footer)
                }
            })
            
            
        });
        
        var namaku = '<?= Auth::user()->name ?>'
        
         $(document).on('click', '.rejej', function(){
             document.getElementById("smpnz").disabled = false;
            var id = $(this).attr('id');
            var body = '';
            $.ajax({
                url: "pengeluaranBy/" + id,
                dataType: "json",
                success: function(response){
                    var data = response.ui
                    // console.log(data);
                    body = `<input type="hidden" name="id_nya" id="id_nya" value="`+data.id+`">
                    <div class="mb-3 row">
                                <label class="col-sm-4 ">User Approve</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+namaku+`</text>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">Alasan</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                    <textarea id="note" name="note" height="150px" class="form-control"></textarea>
                                </div>
                            </div>
                            `
                    $('#rej').html(body);
                }
            })
        })
        
        $(document).on('click', '.editod', function(){
            document.getElementById('nom_hide').style.display = "none";
            document.getElementById('input_hide').style.display = "block";
            
            document.getElementById('ket_hide').style.display = "none";
            document.getElementById('text_hide').style.display = "block";
            
            document.getElementById('foot_hide').style.display = "none";
            document.getElementById('submit_hide').style.display = "block";
        })
        
        $(document).on('click', '.gagal', function(){
            document.getElementById('nom_hide').style.display = "block";
            document.getElementById('input_hide').style.display = "none";
            
            document.getElementById('ket_hide').style.display = "block";
            document.getElementById('text_hide').style.display = "none";
            
            document.getElementById('foot_hide').style.display = "block";
            document.getElementById('submit_hide').style.display = "none";
        })
        
        $('#reject_form').on('submit', function(event) {
            
            var id = $('#id_nya').val();
            var aksi = 'reject';
            var alasan = $('#note').val();
            console.log(id)
            event.preventDefault();
    
            $.ajax({
                url: "aksipeng",
                method: "POST",
                data: {
                    id: id,
                    alasan: alasan,
                    aksi: aksi
                },
                dataType: "json",
                beforeSend: function() {
                    toastr.warning('Memproses....');
                    document.getElementById("smpnz").disabled = true;
                },
                success: function(data) {
                    $('#reject_form')[0].reset();
                    $('#modal-reject').hide();
                    $('.modal-backdrop').remove();
                    $("body").removeClass("modal-open")
                    // $('#user_table').DataTable().ajax.reload();
                    $('#user_table').DataTable().ajax.reload(null, false);
                    toastr.success('Berhasil');
                }
            });

        });
        
        $(document).on('click', '#aksis', function() {
            if ($('#advsrc').val() == 'tutup') {
                 $('.filters').css('display', 'table');
                $('.cari input').css('display', 'block');
            } else {
                $('#advsrc').val('tutup');
                $('.cari input').css('display', 'none');
            }
        })
        
        $('#user_table thead tr')
            .clone(true)
            .addClass('filters')
            .appendTo('#user_table thead');


        var level = '{{ Auth::user()->keuangan}}';
        
        load_data();

        function load_data() {
            
            
            var via = $('#via').val();
            var dari = $('#dari').val();
            var sampai = $('#sampai').val();
            var stts = $('#stts').val();
            var kntr = $('#kntr').val();
            $('#user_table').DataTable({

                //   processing: true,
                serverSide: true,
                // responsive: true,
                // scrollX: true,
                
                // scrollX: true,
                // scrollCollapse: true,
                // fixedColumns: ( level == 'admin' || level == 'keuangan pusat' ?  {
                //     left: 0,
                //     right: 2,
                // } : {
                //     left: 0,
                //     right: 1,
                // }),
                
                // orderCellsTop: true,
                // fixedHeader: false,
                
                language: {
                    paginate: {
                        next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
                        previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>'
                    }
                },

                ajax: {
                    url: "pengeluaran",
                    data: {
                        via: via,
                        dari: dari,
                        sampai: sampai,
                        stts: stts,
                        kntr: kntr
                    }
                },
                columns: [
                    {
                        data: 'tgll',
                        name: 'tgll',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'jenis_transaksi',
                        name: 'jenis_transaksi'
                    },
                    {
                        data: 'keterangan',
                        name: 'keterangan'
                    },
                    {
                        data: 'qty',
                        name: 'qty'
                    },
                    {
                        data: 'jml',
                        name: 'jml'
                    },
                    {
                        data: 'user_i',
                        name: 'user_i'
                    },
                    {
                        data: 'user_a',
                        name: 'user_a'
                    },
                    {
                        data: 'donatur',
                        name: 'donatur'
                    },
                    {
                        data: 'program',
                        name: 'program'
                    },
                    {
                        data: 'kantorr',
                        name: 'kantorr',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'tgl',
                        name: 'tgl',
                        searchable: false
                    },
                    {
                        data: 'coa_debet',
                        name: 'coa_debet',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'coa_kredit',
                        name: 'coa_kredit',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'apr',
                        name: 'apr'
                    },
                    
                ],
                
                lengthMenu: [
                    [10, 25, 50, 100, 500, -1],
                    [10, 25, 50, 100, 500, "All"]
                ],
                createdRow: function(row, data, index) {
                    $('td', row).eq(10).css('display', 'none'); // 6 is index of column
                    if( data.acc ==  0){
                        $(row).addClass('text-danger');
                    }
                    if(level == 'admin' || level == 'keuangan pusat'){
                        $(row).find('td:eq(14)').addClass('hapus');
                    }
                },
                order: [
                    [10, "desc"]
                ],
                
                footerCallback: function( tfoot, data, start, end, display ) {
                    var api = this.api();
                    $.ajax({
                        type: 'GET',
                        url: 'pengeluaran',
                        data: { 
                            tab : 'tab1',
                            via: via,
                            dari: dari,
                            sampai: sampai,
                            stts: stts,
                            kntr: kntr
                            
                        },
                        success: function(data) {
                            console.log(data)
                            var numFormat = $.fn.dataTable.render.number( '.', '.', 0, '' ).display;
                            // Update footer
                            var  p = data.itung.length;
                            $(api.column(3).footer()).html(p);
                            $(api.column(4).footer()).html(numFormat(data.sum));
                        }
                    });
                },
                
                initComplete: function () {
                    var api = this.api();
         
                    // For each column
                    api
                        .columns()
                        .eq(0)
                        .each(function (colIdx) {
                            // Set the header cell to contain the input element
                            var cell = $('.filters th').eq(
                                $(api.column(colIdx).header()).index()
                            );
                            var title = $(cell).text();
                            $(cell).html('<input type="text" placeholder="' + title + '" />');
         
                            // On every keypress in this input
                            $(
                                'input',
                                $('.filters th').eq($(api.column(colIdx).header()).index())
                            )
                                .off('keyup change')
                                .on('change', function (e) {
                                    // Get the search value
                                    $(this).attr('title', $(this).val());
                                    var regexr = '({search})'; //$(this).parents('th').find('select').val();
         
                                    var cursorPosition = this.selectionStart;
                                    // Search the column for that value
                                    api
                                        .column(colIdx)
                                        .search(
                                            this.value != ''
                                                ? regexr.replace('{search}', '(((' + this.value + ')))')
                                                : '',
                                            this.value != '',
                                            this.value == ''
                                        )
                                        .draw();
                                })
                                .on('keyup', function (e) {
                                    e.stopPropagation();
         
                                    $(this).trigger('change');
                                    $(this)
                                        .focus()[0]
                                        .setSelectionRange(cursorPosition, cursorPosition);
                                });
                        });
                },
            });
        }
        
        $(document).on('click', '.hapus', function(){
            var data = $('#user_table').DataTable().row(this).data();
            var id = data.id;
            
            const swalWithBootstrapButtons = Swal.mixin({})
            swalWithBootstrapButtons.fire({
                title: 'Peringatan !',
                text: "Yakin ingin mengpaus data ini ? ",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Iya',
                cancelButtonText: 'Tidak',
                
                }).then((result) => {
                    if (result.isConfirmed) {
                        Swal.fire({
                                title: "Perhatian !",
                                text: "Alasan Data dihapus :",
                                input: 'text',
                                showCancelButton: false ,
                                confirmButtonText: 'Submit',
                            }).then((result) => {
                                  $.ajax({
                                    url: "{{ url('hapus_pengeluaran') }}",
                                    method: "POST",
                                    dataType: "json",
                                    data: {
                                        alasan : result.value, 
                                        id: id,
                                    },
                                    success: function(data) {
                                        if(data.code == 500){
                                            Swal.fire({
                                                icon: 'warning',
                                                title: 'Gagal !',
                                                text: 'Data gagal dihapus',
                                                timer: 2000,
                                                width: 500,
                                                        
                                                showCancelButton: false,
                                                showConfirmButton: false
                                            })
                                        }else{
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Berhasil !',
                                                text: 'Data berhasil dihapus',
                                                timer: 2000,
                                                width: 500,
                                                        
                                                showCancelButton: false,
                                                showConfirmButton: false
                                            })
                                            
                                            $('#user_table').DataTable().destroy();
                                            load_data();
                                        }
                                        
                                    }
                                })        
                                
                            }); 
                        
                        
                    } else if (result.dismiss === Swal.DismissReason.cancel) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Perhatian !',
                            text: 'Data Tidak jadi dihapus',
                            timer: 2000,
                            width: 500,
                                            
                            showCancelButton: false,
                            showConfirmButton: false
                        }) 
                    }
                })
            
        })
        
        $(document).on('click', '.aksi', function() {
            var id = $(this).attr('id');
            var aksi = $(this).attr('data');
            
            $.ajax({
                url: "aksipeng",
                method: "POST",
                data: {
                    id: id,
                    aksi: aksi
                },
                dataType: "json",
                success: function(data) {
                    $('#modals').modal('toggle');
                    $('.modal-backdrop').remove();
                    $("body").removeClass("modal-open")
                    // $('#user_table').DataTable().ajax.reload();
                    $('#user_table').DataTable().ajax.reload(null, false);
                    toastr.success('Berhasil')
                }
            })
        })
        
        $(document).on('click', '.cok', function() {
            var id = $(this).attr('id');
            var ket = $('#edket').val();
            var nominal = $('#ednom').val();
            
            $.ajax({
                url: "editspeng",
                method: "POST",
                data: {
                    id: id,
                    ket: ket,
                    nominal: nominal
                },
                dataType: "json",
                success: function(data) {
                    $('#modals').modal('toggle');
                    $('.modal-backdrop').remove();
                    $("body").removeClass("modal-open")
                    $('#user_table').DataTable().ajax.reload(null, false);
                    // $('#user_table').DataTable().ajax.reload();
                    toastr.success('Berhasil')
                }
            })
        })
        

        $('.js-example-basic-single').select2();



        $(document).on('click', '.edd', function() {
            var id = $(this).attr('id');
            console.log(id);
            $.ajax({
                url: "riwayatdonasi/" + id,
                dataType: "json",
                success: function(data) {
                    window.location.href = "transaksi";
                    console.log(data);
                    $('#id_hidden').val(id);
                }
            })
        })

        var firstEmptySelect3 = false;

        function formatSelect3(result) {
            if (!result.id) {
                if (firstEmptySelect3) {
                    firstEmptySelect3 = false;
                    return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                }
            }else{
                var isi = '';
                
                if (result.parent == 'y') {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                        '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                    '</div>';
                } else {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4">' + result.coa + '</div>' +
                        '<div class="col-lg-8">' + result.nama_coa + '</div>'
                    '</div>';
                }
    
                return isi;
            }

            
        }
        
        function formatResult3(result) {
            if (!result.id) {
                if (firstEmptySelect3) {
                    return '<div class="row">' +
                            '<div class="col-lg-11"><b>Nama Akun</b></div>'
                        '</div>';
                }
            }
    
            var isi = '';
            
            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-11"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-11">' + result.nama_coa + '</div>'
                '</div>';
            }
            return isi;
        }

        function matcher3(query, option) {
            firstEmptySelect3 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }


        $('.saldd').on('change', function() {
            var prog = $('option:selected', '.js-example-basic-singley').text();
            var ex = prog.split("-");
            var p = $("#saldo_dana").select2('data')[0].coa;
            console.log(p);
            var level = ex[1].toString();

            var action_url = '';


            if (level === " Dana Yang Dilarang Syariah") {
                action_url = "getcoadilarang";
            } else if (level === " Dana APBN/APBD") {
                action_url = "getcoaapbn";
            } else if (level === " Dana Wakaf") {
                action_url = "getcoawakaf";
            } else if (level === " Dana Infaq/Sedekah Tidak Terikat") {
                action_url = "getcoainfaqtd";
            } else if (level === " Dana Hibah") {
                action_url = "getcoahibah";
            } else if (level === " Dana Infaq / Sedekah Terikat") {
                action_url = "getcoainfaqt";
            } else if (level === " Dana Zakat") {
                action_url = "getcoazkt";
            } else if (level === " Dana Amil") {
                action_url = "getcoaamil";
            }

            $.ajax({
                url: action_url,
                data: {level : level},
                type: 'GET',
                success: function(response) {
                    //  console.log (response)
                    $("#jenis_t").select2().val('').empty();
                    $('#jenis_t').val('').trigger('change');
                    $('.js-example-basic-single').select2({
                        data: response,
                        width: '100%',
                        // tags: 'true',
                        dropdownCssClass: 'droppp',
                        // allowClear: true,
                        templateResult: formatSelect3,
                        templateSelection: formatResult3,
                        escapeMarkup: function(m) {
                            return m;
                        },
                        matcher: matcher3
                    });
                }
            });
            
            $.ajax({
                url: "{{ url('cari_saldo') }}",
                data: {
                    coa : p,
                    level: level
                },
                type: 'GET',
                success: function(data) {
                    // $('#saldo_dananya_saldo').html(data.saldo)
                    $('#saldo_dananya').val(data.saldo);
                    var b = data.saldo;
                    if (b != null) {
                        var reverse = b.toString().split('').reverse().join(''),
                            total = reverse.match(/\d{1,3}/g);
                        total = total.join('.').split('').reverse().join('');
                        $('.saldo_dananya_saldo').html('');
                        $('.saldo_dananya_saldo').html('Rp. ' + total);
                    } else {
                        $('.saldo_dananya_saldo').html('');
                        $('.saldo_dananya_saldo').html('Rp. 0');
                    }
                }
            });
        })


        var firstEmptySelect4 = true;

        function formatSelect4(result) {
            if (!result.id) {
                if (firstEmptySelect4) {
                    // console.log('showing row');
                    firstEmptySelect4 = false;
                    return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                } else {
                    // console.log('skipping row');
                    return false;
                }
                console.log('result');
                // console.log(result);
            }

            var isi = '';
            // console.log(result.parent);
            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                    '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-4">' + result.coa + '</div>' +
                    '<div class="col-lg-8">' + result.nama_coa + '</div>'
                '</div>';
            }

            return isi;
        }

        function matcher4(query, option) {
            firstEmptySelect4 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }
        $.ajax({
            url: 'getcoapersediaan',
            type: 'GET',
            success: function(response) {
                //  console.log (response)
                $('.js-example-basic-singlex').select2({
                    data: response,
                    width: '100%',
                    templateResult: formatSelect4,
                    templateSelection: formatSelect4,
                    escapeMarkup: function(m) {
                        return m;
                    },
                    matcher: matcher4

                })
            }
        });

        var firstEmptySelect5 = false;

    function formatSelect5(result) {
        if (!result.id) {
            if (firstEmptySelect5) {
                firstEmptySelect5 = false;
                return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                } 
            }else{
                var isi = '';
                if (result.parent == 'y') {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                        '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                    '</div>';
                } else {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4">' + result.coa + '</div>' +
                        '<div class="col-lg-8">' + result.nama_coa + '</div>'
                    '</div>';
                }
    
                return isi;
            }

            
        }
        
        function formatResult5(result) {
            if (!result.id) {
                if (firstEmptySelect5) {
                    return '<div class="row">' +
                            '<div class="col-lg-11"><b>Nama Akun</b></div>'
                        '</div>';
                } else {
                    return false;
                }
            }
    
            var isi = '';
            
            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-11"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-11">' + result.nama_coa + '</div>'
                '</div>';
            }
            return isi;
        }

        function matcher5(query, option) {
            firstEmptySelect5 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }
        $.ajax({
            url: 'getcoasumberdana',
            type: 'GET',
            success: function(response) {
                $('.js-example-basic-singley').select2({
                    data: response,
                    // width: '100%',
                    dropdownCssClass: 'droppp',
                    templateResult: formatSelect5,
                    templateSelection: formatResult5,
                    escapeMarkup: function(m) {
                        return m;
                    },
                    matcher: matcher5

                })
            }
        });

        var firstEmptySelect6 = true;

        function formatSelect6(result) {
            
            if (!result.id) {
                if (firstEmptySelect6) {
                    // console.log('showing row');
                    firstEmptySelect6 = false;
                    return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                }
                else{
                    return false;
                }
            }
            
            var isi = '';
            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                    '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-4">' + result.coa + '</div>' +
                    '<div class="col-lg-8">' + result.nama_coa + '</div>'
                '</div>';
            }
                
            return isi;
            
        }
        
        function formatResult6(result) {
            if (!result.id) {
                if (firstEmptySelect6) {
                    return '<div class="row">' +
                            '<div class="col-lg-11"><b>Nama Akun</b></div>'
                        '</div>';
                } else {
                    return false;
                }
            }
    
            var isi = '';
            
            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-11"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-11">' + result.nama_coa + '</div>'
                '</div>';
            }
            return isi;
        }

        function matcher6(query, option) {
            firstEmptySelect6 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }
        
        $('.js-example-basic-single-pengirim').select2()
        
        $('#kantor_m').on('change', function(){
            $("#pengirim_m").empty().trigger('change')
            // $('#pengirim_m').trigger('change');
            var unit = $(this).val();
            
            
            $.ajax({
                url: "{{ url('getcoamutasipengirim')}}",
                data: { unit: unit },
                type: 'GET',
                success: function(response) {
                    
                    $('.js-example-basic-single-pengirim').select2({
                        // dropdownCssClass: 'drops',
                        data: response,
                        width: '100%',
                        selectOnClose: true,
                        templateResult: formatSelect6,
                        templateSelection: formatResult6,
                        escapeMarkup: function(m) {
                            return m;
                        },
                        matcher: matcher6
                    });
                    
                    console.log('ini', $('.js-example-basic-single-pengirim').val());
                    
                    var prog = $('option:selected', '.js-example-basic-single-pengirim').text();
                    var coa = $('.js-example-basic-single-pengirim').select2('val')
                    
                    var level = '';
                    level = 'Mutasi Dari ' + prog + ' ke ';
                    $("#ket_m").val(level).trigger('change');
                    
                    $.ajax({
                        url: "get_saldo_pengirim",
                        method: "GET",
                        data: {
                            coa: coa
                        },
                        // dataType:"json",
                        success: function(data) {
                            $('#saldopengirim').val(data);
                            var b = data;
                            if (b != null) {
                                var reverse = b.toString().split('').reverse().join(''),
                                    total = reverse.match(/\d{1,3}/g);
                                total = total.join('.').split('').reverse().join('');
                                // $('.saldo_pengirim').html('');
                                $('.saldo_pengirim').html('Saldo Rp. ' + total);
                            } else {
                                // $('.saldo_pengirim').html('');
                                $('.saldo_pengirim').html('Saldo Rp. 0');
                            }
        
                        }
                    })
                }
            });
        });;

        var firstEmptySelect7 = false;

        function formatSelect7(result) {
            if (!result.id) {
                if (firstEmptySelect7) {
                    // console.log('showing row');
                    firstEmptySelect7 = false;
                    return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                }
            }else{
                var isi = '';
            
                if (result.parent == 'y') {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                        '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                    '</div>';
                } else {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4">' + result.coa + '</div>' +
                        '<div class="col-lg-8">' + result.nama_coa + '</div>'
                    '</div>';
                }
    
                return isi;
            }
            
        }
        
        function formatResult7(result) {
            if (!result.id) {
                if (firstEmptySelect7) {
                    return '<div class="row">' +
                            '<div class="col-lg-11"><b>Nama Akun</b></div>'
                        '</div>';
                } else {
                    return false;
                }
            }
    
            var isi = '';
            
            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-11"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-11">' + result.nama_coa + '</div>'
                '</div>';
            }
            return isi;
        }

        function matcher7(query, option) {
            firstEmptySelect7 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }
        $.ajax({
            url: 'getcoamutasipenerima',
            type: 'GET',
            success: function(response) {
                //  console.log (response)
                $('.js-example-basic-single-penerima').select2({
                    dropdownCssClass: 'drops',
                    data: response,
                    width: '100%',
                    selectOnClose: true,
                    templateResult: formatSelect7,
                    templateSelection: formatResult7,
                    escapeMarkup: function(m) {
                        return m;
                    },
                    matcher: matcher7

                });
            }
        });

        var firstEmptySelect8 = true;

        function formatSelect8(result) {
            if (!result.id) {
                if (firstEmptySelect8) {
                    // console.log('showing row');
                    firstEmptySelect8 = false;
                    return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                }
            }else{
                var isi = '';
                // console.log(result.parent);
                if (result.parent == 'y') {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                        '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                    '</div>';
                } else {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4">' + result.coa + '</div>' +
                        '<div class="col-lg-8">' + result.nama_coa + '</div>'
                    '</div>';
                }
    
                return isi;
            }

            
        }
        
        function formatResult8(result) {
            if (!result.id) {
                if (firstEmptySelect8) {
                    return '<div class="row">' +
                            '<div class="col-lg-11"><b>Nama Akun</b></div>'
                        '</div>';
                } else {
                    return false;
                }
            }
    
            var isi = '';
            
            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-11"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-11">' + result.nama_coa + '</div>'
                '</div>';
            }
            return isi;
        }

        function matcher8(query, option) {
            firstEmptySelect8 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }

        var kantor = $('#kantor').val();
        //  console.log (kantor);
        $.ajax({
            url: 'getcoapengeluaranbank',
            type: 'GET',
            data: {
                kantor: kantor
            },
            success: function(response) {
                console.log(response)
                $('.select30').select2({
                    data: response,
                    width: '100%',
                    templateResult: formatSelect8,
                    templateSelection: formatResult8,
                    escapeMarkup: function(m) {
                        return m;
                    },
                    matcher: matcher8

                });
            }
        });
        
        function check_submit() {
          if ($(this).val().length == 0) {
            $(":submit").attr("disabled", true);
          } else {
            $(":submit").removeAttr("disabled");
          }
        }

   $('.carianggaran').on('change', function() {
            var prog = $('option:selected', '.js-example-basic-single').text();
            var ex = prog.split("-");
            // var p = $("#jenis_t").select2('data')[0].coa;
            var p = document.forms["sample_form"]["jenis_t"].value;
            var kntr = document.forms["sample_form"]["kantor"].value;
            var  tgl = $('#tgl_now').val()
              $.ajax({
                url: "{{ url('data_anggaran') }}",
                data: {
                    p : p,
                    kntr:kntr,
                    tgl:tgl,
                },
                type: 'GET',
                success: function(data) {
                console.log(data);
                $('#pengajuannya').val(data.total);
                var tot = data.length
                console.log(tot);
               
                var jml = 0
                var nominal = 0
                var relokasi = 0
                var tambahan = 0
                var cair = 0
                  for (var i = 0; i < tot; i++) {
                    jml += data[i].total
                   cair += data[i].uang_pengeluaran
                  }
                 var perhitungan = jml
                console.log(perhitungan);
                              var reverse = perhitungan.toString().split('').reverse().join('');
                                total = reverse.match(/\d{1,3}/g);
                                total = total.join('.').split('').reverse().join('');
                            $('#pengajuannya').html('');
                            $('#pengajuannya').html('Rp. ' + total);
                    
                 
                    // var b = data.total;
                    // console.log(b);
                    // console.log(data);
                    // if (b != null) {
                    //     var reverse = b.toString().split('').reverse().join(''),
                    //         total = reverse.match(/\d{1,3}/g);
                    //     total = total.join('.').split('').reverse().join('');
                    //     $('.pengajuannya').html('');
                    //     $('.pengajuannya').html('Rp. ' + total);
                    // } else {
                    //     $('.pengajuannya').html('');
                    //     $('.pengajuannya').html('Rp. 0');
                    // }
                }
            });
        })

        var arr = [];

  $('#add').on('click', function() {
            
               $.ajax({
                        type: 'GET',
                        url: 'min_waktu',
                        success: function(data) {
            var waktu1 = data.min_anggaran
                        
            var p = document.forms["sample_form"]["jenis_t"].value;
            var kntr = document.forms["sample_form"]["kantor"].value;
           

        $.ajax({
                url: "{{ url('data_anggaran') }}",
                data: {
                    p : p,
                    kntr:kntr,  
                },
                type: 'GET',
                success: function(data) {
                $('#pengajuannya').val(data.total);
                var tot = data.length
                var jml = 0
                var tglpenga = ''
                var tglcreat = ''
                var nominal = 0
                var relokasi = 0
                var tambahan = 0
                  for (var i = 0; i < tot; i++) {
                     jml += data[i].total 
                     tglpenga = data[i].tanggal
                      tglcreat = data[i].created
                      var id = data[i].id_anggaran
                    var cair = data[i].uang_pengeluaran
                  }

          totalakhir =  jml ;
          
            var kntr = document.forms["sample_form"]["kantor"].value;
            var jns_t = document.forms["sample_form"]["jenis_t"].value;
            var nmnl = document.forms["sample_form"]["nominal"].value;
            var keter = document.forms["sample_form"]["ket"].value;
            var bayar = document.forms["sample_form"]["via_bayar"].value;
            var bank = document.forms["sample_form"]["bank"].value;
            var noncash = document.forms["sample_form"]["non_cash"].value;
            var saldo_dana = document.forms["sample_form"]["saldo_dana"].value;
            var jbt = document.forms["sample_form"]["jbt"].value;
            var bukti = document.forms["sample_form"]["foto"].value;
            var jjjj = nmnl.replace(/\./g, "")
            var id_anggaran = id;
            var date1 =  new Date($('#tgl_now').val());
            var date2 =  new Date(tglpenga);
            var date3 = new Date(tglcreat);
            
             var tanggal1 = date1.setDate(date1.getDate());
             var tanggal2 = date2.setDate(date2.getDate() - waktu1);
             var tanggal3 = date3.setDate(date3.getDate() + waktu1); 
             
             
        console.log(tanggal1);
        console.log(tanggal2);
        console.log(tanggal3);
             
          if (bayar == "") {
                toastr.warning('Pilih Via Pembayaran');
                return false;
            } else if (bayar == "bank" && bank == "") {
                toastr.warning('Pembayaan via bank kosong harap diisi !');
                return false;
            } else if (bayar == "noncash" && noncash == "") {
                toastr.warning('Pembayaan via non cash kosong harap diisi !');
                return false;
            } else if (kntr == "") {
                toastr.warning('Pilih Kantor');
                return false;
            } else if (jenis_t == "") {
                toastr.warning('Pilih Jenis Transaksi');
                return false;
            } else if (nmnl == "") {
                toastr.warning('Pilih Nominal');
                return false;
              }
              else if (bukti == "") {
                toastr.warning('Upload Bukti Pengeluaran');
                return false;
            } 
            else if (jbt == "") {
                toastr.warning('Pilih Department');
                return false;
            } else if (saldo_dana == "") {
                toastr.warning('Pilih Saldo Dana');
                return false;
            } else if (parseFloat(totalakhir) < jjjj) {
                toastr.warning('Nominal Lebih besar dari Jumlah yang di ajukan bener kan ?');
                return false;
            }  else 
            if (tanggal2 > tanggal1  ) {
                toastr.warning("Tanggal Harus kurang dari "+ waktu1 + " hari dari Hari Pencairan");
                return false;
            }
        
        
        
            // } else if (nmnl <=  input ) {
            //     toastr.warning('Nominal Lebih besar dari Jumlah yang di ajukan');
            //     return false;
            
          
            
          
          
            var prog = $('option:selected', '.js-example-basic-single').text();
            var ex = prog.split("-");
            var level = ex[1];

            var salddd = $('option:selected', '.js-example-basic-singley').text();
            var ew = salddd.split("-");
            var saldo = ew[1];

            var id_kantor = $('#kantor').val();
            var jabatan = $('#jbt').val();
            var pembayaran = $('#via_bayar').val();
            var kantor = $('#kantor').find("option:selected").attr('data-value');
            var jenis_trans = level;
            var coa = $('.js-example-basic-single').select2("val");
            var user_input = $('#user_input').val();
            var bank = $('#bank').val();
            var non_cash = $('.js-example-basic-singlex').select2("val");
            var tgl = $('#tgl_now').val();
            var qty = 1;
            var keterangan = $('#ket').val();
            var nominal = $('#nominal').val();
            
            var foto = $('#base64').val();
            var namafile = $('#nama_file').val();

         const date = new Date();

            let day = date.getDate();
            let month = date.getMonth() + 1;
            let year = date.getFullYear();
            
            var currentDate = `${year}-${month}-${day}`;
            var format = tgl == '' ? currentDate : tgl;
            var replaced = format.split('-').join('');
                
            var string = '3'+replaced+id_kantor+user_input;
            var y = '';
            
            y = Array.from({length: 20}, () => string[Math.floor(Math.random() * string.length)]).join('');
            
            var hps = y;

      
      
        // var now = Math.floor(new Date(date1).getTime() / 1000)
        //   console.log("ini waktu skr " + now);
        // var threeDayBefore = Math.floor(new Date(date2.setDate(date2.getDate() - waktu1 )).getTime() / 1000)
        //   console.log("ini waktu - 4 " + threeDayBefore);
        // var threeDayafter = Math.floor(new Date(date2.setDate(date2.getDate() +8 )).getTime() / 1000)
        //   console.log("ini waktu + 3 " + threeDayafter);
        
        // var kon1 = threeDayBefore  >= now;
        // var kon2 = threeDayafter  <= now;
        
   
        
            // if (tanggal2 > tanggal1  ) {
            //     toastr.warning("Tanggal Harus kurang dari 3 hari dari Pencairan");
            //     return false;
            // }
            // else if(tanggal3 > waktu1 ){
            //     toastr.warning("Tanggal harus lebih dari "+ waktu1 +" hari dari tanggal input");
            //     return false;
            // }
            
            // if (kon1 || kon2) {
            //     toastr.warning("Tanggal harus kurang dari "+ waktu1 +" hari dari tanggal Pencairan " + " Maksimal Tanggal harus dari +3 hari dari tanggal Pengajuan" );
            //     return false;
                
            //     } else if (parseFloat(jml) < jjjj) {
            //     toastr.warning('Nominal Lebih besar dari Jumlah yang di ajukan bener kan ?');
            //     return false;
            // } 
            
            arr.push({
                id_anggaran: id_anggaran,
                id_kantor: id_kantor,
                coa: coa,
                jabatan: jabatan,
                kantor: kantor,
                bank: bank,
                non_cash: non_cash,
                saldo: saldo,
                foto: foto,
                namafile: namafile,
                jenis_trans: jenis_trans,
                pembayaran: pembayaran,
                user_input: user_input,
                keterangan: keterangan,
                nominal: nominal,
                tgl: tgl,
                qty: qty,
                hps: hps
            });
           
          
            $('#ket').val('');
            $('#tgl_now').val('');
            $("#via_bayar").val('').trigger('change');
            $('#nominal').val('');
            // $("#kantor").val('').trigger('change');
            // $("#jbt").val('').trigger('change');
            $("#jenis_t").val('').trigger('change');
            // $("#saldo_dana").val('').trigger('change');
            // $(".saldo_pengeluaran").html('Rp. 0');
            $(".judul").html('');
            
            var foto1 = $('#foto').val('');
            var foto = $('#base64').val('');
            var namafile = $('#nama_file').val('');
            
            load_array()    
          
                    }
                });     
            }
        });
            
        });




      

        $('#tambah').click(function() {
            $('#smpn').removeAttr('disabled');
            document.getElementById("smpnz").disabled = false;
            $('#sample_form')[0].reset();
            // $("#id_program_parent").val('').trigger('change');
            // $("#id_sumber_dana").val('').trigger('change');
            // $("#coa1").val('').trigger('change');
            // $("#coa2").val('').trigger('change');
            // $("#parent").val('').trigger('change');
            // $("#level").val('').trigger('change');
            // $("#spc").val('').trigger('change');
            // // $("#aktif").val('').trigger('change');
            // $("#coa_individu").val('').trigger('change');
            // $("#coa_entitas").val('').trigger('change');

        });

        $('#mutasi').click(function() {
            $('#smpnn').removeAttr('disabled');
            document.getElementById("smpnn").disabled = false;
            $('#sample_form1')[0].reset();
            // $("#id_program_parent").val('').trigger('change');
            // $("#id_sumber_dana").val('').trigger('change');
            // $("#coa1").val('').trigger('change');
            // $("#coa2").val('').trigger('change');
            // $("#parent").val('').trigger('change');
            // $("#level").val('').trigger('change');
            // $("#spc").val('').trigger('change');
            // // $("#aktif").val('').trigger('change');
            // $("#coa_individu").val('').trigger('change');
            // $("#coa_entitas").val('').trigger('change');

        });

        $('.js-example-basic-single-pengirim').on('change', function() {
            var prog = $('option:selected', '.js-example-basic-single-pengirim').text();
            var coa = $('.js-example-basic-single-pengirim').select2('val')
            var level = '';
            level = 'Mutasi Dari ' + prog + ' ke ';
            $("#ket_m").val(level).trigger('change');
            $.ajax({
                url: "get_saldo_pengirim",
                method: "GET",
                data: {
                    coa: coa
                },
                // dataType:"json",
                success: function(data) {
                    $('#saldopengirim').val(data);
                    var b = data;
                    if (b != null) {
                        var reverse = b.toString().split('').reverse().join(''),
                            total = reverse.match(/\d{1,3}/g);
                        total = total.join('.').split('').reverse().join('');
                        // $('.saldo_pengirim').html('');
                        $('.saldo_pengirim').html('Saldo Rp. ' + total);
                    } else {
                        // $('.saldo_pengirim').html('');
                        $('.saldo_pengirim').html('Saldo Rp. 0');
                    }

                }
            })
        })

     $('#stts').on('change', function(){
            if($(this).val() == '2'){
                document.getElementById("one").style.display = "block";
            }else{
                document.getElementById("one").style.display = "none";
                $('#user_table').DataTable().destroy();
                load_data();
            }
        })  

        // $('.okkk').on('change', function(){
        //     var prog  = $('option:selected', '.js-example-basic-single-pengirim').text();

        //     var level = '';

        //     $("#ket_m").val(level).trigger('change');  
        // })

        $('.js-example-basic-single-penerima').on('change', function() {
            var prog = $('option:selected', '.js-example-basic-single-penerima').text();
            var ket = $('#ket_m').val();
            var levelo = '';
            var coa = $('.js-example-basic-single-penerima').select2('val');
            var kantor = $('.js-example-basic-single-penerima').select2('val');
            if (prog == $('option:selected', '.js-example-basic-single-pengirim').text()) {
                $("#penerima_m").val('').trigger('change');
                levelo = ket;
                $("#ket_m").val(levelo).trigger('change');
                toastr.warning('Pengirim dan Penerima tidak boleh sama !');
                return false;
            } else {
                levelo = ket + '' + prog;
                $("#ket_m").val(levelo).trigger('change');
            }
            console.log(levelo);
            $.ajax({
                url: "get_saldo_penerima",
                method: "GET",
                data: {
                    coa: coa
                },
                // dataType:"json",
                success: function(data) {
                    $('#saldopenerima').val(data);
                    // console.log(`x` + data);
                    var b = data;
                    if (b != null) {
                        var reverse = b.toString().split('').reverse().join(''),
                            total = reverse.match(/\d{1,3}/g);
                        total = total.join('.').split('').reverse().join('');
                        // $('.saldo_penerima').html('');
                        $('.saldo_penerima').html('Saldo Rp. ' + total);
                    } else {
                        // $('.saldo_penerima').html('');
                        $('.saldo_penerima').html('Saldo Rp. 0');
                    }

                }
            })

        })

        $('.js-example-basic-single').on('change', function() {

            var prog = $('option:selected', '.js-example-basic-single').text();

            var ex_prog = prog.split("-");

            if (ex_prog[0] == "y") {
                $("#jenis_t").val('').trigger('change');
                toastr.warning('Pilih Transaksi jenis Child');
                return false;
            }
        })

        $('.cekin').on('change', function() {
            var kantor = $('#kantor').val();
            var via = $('#via_bayar').val();
            var bank = $('#bank').val();
            $('.judul').html(via).trigger('change');
            $.ajax({
                url: "get_saldo_pengeluaran",
                method: "GET",
                data: {
                    kantor: kantor,
                    via: via,
                    bank: bank
                },
                // dataType:"json",
                success: function(data) {
                    console.log(data);
                    $('#saldopengeluaran').val(data);
                    var b = data
                    if (b != null) {
                        var reverse = b.toString().split('').reverse().join(''),
                            total = reverse.match(/\d{1,3}/g);
                        total = total.join('.').split('').reverse().join('');
                        $('.saldo_pengeluaran').html('');
                        $('.saldo_pengeluaran').html('Rp. ' + total);
                    } else {
                        $('.saldo_pengeluaran').html('');
                        $('.saldo_pengeluaran').html('Rp. 0');
                    }


                }
            });



            $.ajax({
                url: 'getcoapengeluaranbank',
                type: 'GET',
                data: {
                    kantor: kantor
                },
                success: function(response) {
                    console.log(response)
                    $("#bank").select2().val('').empty();
                    $('.select30').select2({
                        data: response,
                        width: '100%',
                        templateResult: formatSelect8,
                        templateSelection: formatResult8,
                        escapeMarkup: function(m) {
                            return m;
                        },
                        matcher: matcher8

                    });
                }
            })

        })

        $('#kantor').on('change', function() {
            var kantor = $('#kantor').val();
            var via = $('#via_bayar').val();
            var bank = $('#bank').val();
            $('.judul').html(via).trigger('change');
            $.ajax({
                url: "get_saldo_pengeluaran",
                method: "GET",
                data: {
                    kantor: kantor,
                    via: via,
                    bank: bank
                },
                // dataType:"json",
                success: function(data) {
                    console.log(data);
                    $('#saldopengeluaran').val(data);
                    var b = data;
                    if (b != null) {
                        var reverse = b.toString().split('').reverse().join(''),
                            total = reverse.match(/\d{1,3}/g);
                        total = total.join('.').split('').reverse().join('');
                        $('.saldo_pengeluaran').html('');
                        $('.saldo_pengeluaran').html('Rp. ' + total);
                    } else {
                        $('.saldo_pengeluaran').html('');
                        $('.saldo_pengeluaran').html('Rp. 0');
                    }



                }
            })



            $.ajax({
                url: 'getcoapengeluaranbank',
                type: 'GET',
                data: {
                    kantor: kantor
                },
                success: function(response) {
                    console.log(response)
                    $("#bank").select2().val('').empty();
                    $('.select30').select2({
                        data: response,
                        width: '100%',
                        templateResult: formatSelect8,
                        templateSelection: formatResult8,
                        escapeMarkup: function(m) {
                            return m;
                        },
                        matcher: matcher8

                    });
                }
            })

        })

        $('#bank').on('change', function() {
            var kantor = $('#kantor').val();
            var via = $('#via_bayar').val();
            var bank = $('#bank').select2('val');
            $('.judul').html(via).trigger('change');
            $.ajax({
                url: "get_saldo_pengeluaran",
                method: "GET",
                data: {
                    kantor: kantor,
                    via: via,
                    bank: bank
                },
                // dataType:"json",
                success: function(data) {
                    console.log(data);
                    $('#saldopengeluaran').val(data);
                    var b = data;
                    if (b != null) {
                        var reverse = b.toString().split('').reverse().join(''),
                            total = reverse.match(/\d{1,3}/g);
                        total = total.join('.').split('').reverse().join('');
                        $('.saldo_pengeluaran').html('');
                        $('.saldo_pengeluaran').html('Rp. ' + total);
                    } else {
                        $('.saldo_pengeluaran').html('');
                        $('.saldo_pengeluaran').html('Rp. 0');
                    }



                }
            })

            $.ajax({
                url: 'getcoapengeluaranbank',
                type: 'GET',
                data: {
                    kantor: kantor
                },
                success: function(response) {
                    //  $("#bank").select2().val('').empty();
                    console.log(response)
                    $('.select30').select2({
                        data: response,
                        width: '100%',
                        templateResult: formatSelect8,
                        templateSelection: formatResult8,
                        escapeMarkup: function(m) {
                            return m;
                        },
                        matcher: matcher8

                    });
                }
            })

        })


        var arr_mut = [];

        $('#add_mutasi').on('click', function() {
            var kntr = document.forms["sample_form1"]["kantor_m"].value;
            var pengirim = document.forms["sample_form1"]["pengirim_m"].value;
            var nmnl = document.forms["sample_form1"]["nominal_m"].value;
            var keter = document.forms["sample_form1"]["ket_m"].value;
            var penerima = document.forms["sample_form1"]["penerima_m"].value;
            var pen = document.forms["sample_form1"]["saldopenerima"].value;
            var peng = document.forms["sample_form1"]["saldopengirim"].value;

            if (pengirim == "") {
                toastr.warning('Pilih Pengirim');
                return false;
            } else if (penerima == "") {
                toastr.warning('Pilih Penerima');
                return false;
            } else if (kntr == "") {
                toastr.warning('Pilih Kantor');
                return false;
            } else if (nmnl == "") {
                toastr.warning('Pilih Nominal');
                return false;
            }

            var pengirim = $('option:selected', '.js-example-basic-single-pengirim').text();
            
            var penerima = $('option:selected', '.js-example-basic-single-penerima').text();

            var id_kantor = $('#kantor_m').val();

            var kantor = $('#kantor_m').find("option:selected").attr('data-value');
            
            var sal_penerima = $('#saldopenerima').val();
            var sal_pengirim = $('#saldopengirim').val();
            var coa_pengirim = $('.js-example-basic-single-pengirim').select2('val');
            var coa_penerima = $('.js-example-basic-single-penerima').select2('val');
            var qty = 1;
            var keterangan = $('#ket_m').val();
            var nominal = $('#nominal_m').val();
            var tgl = $('#tgl_now_m').val();
            
            const date = new Date();

            let day = date.getDate();
            let month = date.getMonth() + 1;
            let year = date.getFullYear();
            
            var currentDate = `${year}-${month}-${day}`;
            var format = tgl == '' ? currentDate : tgl;
            var replaced = format.split('-').join('');
                
            var string = '3'+replaced+id_kantor+user_input;
            var y = '';
            
            y = Array.from({length: 20}, () => string[Math.floor(Math.random() * string.length)]).join('');
            
            var hps = y;
            var user_input = '{{ Auth::user()->id }}';

            arr_mut.push({
                sal_penerima: sal_penerima,
                sal_pengirim: sal_pengirim,
                coa_penerima: coa_penerima,
                coa_pengirim: coa_pengirim,
                id_kantor: id_kantor,
                penerima: penerima,
                pengirim: pengirim,
                kantor: kantor,
                keterangan: keterangan,
                nominal: nominal,
                tgl: tgl,
                qty: qty,
                user_input: user_input,
                hps : hps
            });

            $('#nominal_m').val('');
            $('.js-example-basic-single-penerima').val('').trigger('change');
            $('.js-example-basic-single-pengirim').val('').trigger('change');

            $('.saldo_penerima').html('');
            $('.saldo_pengirim').html('');
            $("#ket_m").val("");

            console.log(arr_mut);

            load_array_mut()
            
        });

        load_array()

        function load_array() {
            console.log(arr);
            var table = '';
            var foot = '';
            var tots = 0;
            var nom = 0;
            var totall = 0;
            var totalo = 0;
            var tot = arr.length;
            if (tot > 0) {
                for (var i = 0; i < tot; i++) {
                    nom = Number(arr[i].nominal.replace(/\./g, ""));
                    tots += Number(arr[i].nominal.replace(/\./g, ""));
                    totall = nom * arr[i].qty;

                    var number_string = totall.toString(),
                        sisa = number_string.length % 3,
                        rupiah = number_string.substr(0, sisa),
                        ribuan = number_string.substr(sisa).match(/\d{3}/g);

                    if (ribuan) {
                        separator = sisa ? '.' : '';
                        rupiah += separator + ribuan.join('.');
                    }

                    totalo = tots * arr[i].qty;
                    // totalo = ;
                    table += `<tr><td>` + arr[i].coa + `</td><td>` + arr[i].jenis_trans + `</td><td>` + arr[i].qty + `</td><td>` + arr[i].nominal + `</td><td>` + rupiah + `</td><td>` + arr[i].keterangan + `</td><td>` + arr[i].kantor + `</td><td><a class="hps btn btn-danger btn-sm" id="` + i + `"><i class="fa fa-trash"></i></a></td></tr>`;
                }

                var number_string = totalo.toString(),
                    sisa = number_string.length % 3,
                    rupiah = number_string.substr(0, sisa),
                    ribuan = number_string.substr(sisa).match(/\d{3}/g);

                if (ribuan) {
                    separator = sisa ? '.' : '';
                    rupiah += separator + ribuan.join('.');
                }
                // console.log(jum);
                foot = `<tr> <td></td> <td><b>Total :</b></td> <td></td> <td></td> <td><b>` + rupiah + `</b></td> <td></td> <td></td> <td></td></tr>`;
            }

            $('#table').html(table);
            $('#foot').html(foot);
        }

        load_array_mut()

        function load_array_mut() {
            console.log(arr_mut);
            var table = '';
            var foot = '';
            var tots = 0;
            var nom = 0;
            var totall = 0;
            var totalo = 0;
            var tot = arr_mut.length;
            if (tot > 0) {
                for (var i = 0; i < tot; i++) {
                    nom = Number(arr_mut[i].nominal.replace(/\./g, ""));
                    tots += Number(arr_mut[i].nominal.replace(/\./g, ""));
                    totall = nom * arr_mut[i].qty;

                    var number_string = totall.toString(),
                        sisa = number_string.length % 3,
                        rupiah = number_string.substr(0, sisa),
                        ribuan = number_string.substr(sisa).match(/\d{3}/g);

                    if (ribuan) {
                        separator = sisa ? '.' : '';
                        rupiah += separator + ribuan.join('.');
                    }

                    totalo = tots * arr_mut[i].qty;
                    // totalo = ;
                    table += `<tr><td>` + arr_mut[i].pengirim + `</td><td>` + arr_mut[i].penerima + `</td><td>` + arr_mut[i].nominal + `</td><td>` + arr_mut[i].keterangan + `</td><td>` + arr_mut[i].kantor + `</td><td><a class="hps_m btn btn-danger btn-sm" id="` + i + `"><i class="fa fa-trash"></i></a></td></tr>`;
                }

                var number_string = totalo.toString(),
                    sisa = number_string.length % 3,
                    rupiah = number_string.substr(0, sisa),
                    ribuan = number_string.substr(sisa).match(/\d{3}/g);

                if (ribuan) {
                    separator = sisa ? '.' : '';
                    rupiah += separator + ribuan.join('.');
                }
                // console.log(jum);
                foot = `<tr> <td></td><td><b>Total :</b></td><td><b>` + rupiah + `</b></td> <td></td> <td></td> <td></td></tr>`;
            }



            $('#tablex').html(table);
            $('#footx').html(foot);
        }

        $('#sample_form').on('submit', function(event) {
            
            if(arr.length > 0){
                
                event.preventDefault();
    
                $.ajax({
                    url: "post_pengeluaran",
                    method: "POST",
                    data: {
                        arr: arr
                    },
                    dataType: "json",
                    beforeSend: function() {
                        toastr.warning('Memproses....');
                        document.getElementById("smpn").disabled = true;
                    },
                    success: function(data) {
                        $('#sample_form')[0].reset();
                        $('#smpn').attr('disabled', true);
                        $('#table tr').remove();
                        arr = [];
                        $('#foot tr').remove();
                        $('#modal-default1').hide();
                        $('.modal-backdrop').remove();
                        $("body").removeClass("modal-open")
                        $('#user_table').DataTable().ajax.reload();
                        toastr.success('Berhasil');
                    }
                });
                
            }else{
                
                toastr.warning('Cek Dulu');
                return false;
            }

        });

    $('#acc_semua').on('click', function() {
            var via = $('#via').val();
            var dari = $('#dari').val();
            var sampai = $('#sampai').val();
            var kntr = $('#kntr').val();
            if (confirm('Apakah anda yakin ingin Aprrove All Data ini Semua ?')) {
                if (confirm('Apakah Anda yakin ??')) {
                    $.ajax({
                        url: "{{ url('acc_semua') }}",
                        type: 'GET',
                        data: {
                            via:via,
                            sampai: sampai,
                            dari: dari,
                            kntr: kntr,
                        },

                        success: function(response) {
                            $('#user_table').DataTable().destroy();
                            load_data();
                            toastr.success('Berhasil');
                        }
                    });
                } else {

                }
            } else {

            }
        });

        $('#sample_form1').on('submit', function(event) {

            event.preventDefault();

            $.ajax({
                url: "{{ url('post_mutasi') }}",
                method: "POST",
                data: {
                    arr_mut: arr_mut
                },
                dataType: "json",
                success: function(data) {
                    $('.blokkkk').attr('disabled', true);
                    $('#sample_form1')[0].reset();
                    $('#tablex tr').remove();
                    arr_mut = [];
                    $('#footx tr').remove();
                    $('#modal-default2').hide();
                    $('.modal-backdrop').remove();
                    $("body").removeClass("modal-open")
                    $('#user_table').DataTable().ajax.reload();
                    toastr.success('Berhasil');
                }
            });
        });

        $(document).on('click', '.hps', function() {
            // $('#hps_data').val(this);
            if (confirm('Apakah anda Ingin Menghapus Data Ini ??')) {
                arr.splice($(this).attr('id'), 1);
                load_array();
            }
        })
        
        $(document).on('click', '.hps_m', function() {
            // $('#hps_data').val(this);
            if (confirm('Apakah anda Ingin Menghapus Data Ini ??')) {
                arr_mut.splice($(this).attr('id'), 1);
                load_array_mut();
            }
        })

        $('#via_bayar').on('change', function() {
            if ($(this).val() == 'bank') {
                $('#bank_hide').removeAttr('hidden');
                $('#noncash_hide').attr('hidden', 'hidden');
            } else if ($(this).val() == 'noncash') {
                $('#noncash_hide').removeAttr('hidden');
                $('#bank_hide').attr('hidden', 'hidden');
            } else {
                $('#bank_hide, #noncash_hide').attr('hidden', 'hidden');
            }
        })

        $('#via_bayared').on('change', function() {
            if ($(this).val() == 'bank') {
                $('#bank_hideed').removeAttr('hidden');
                $('#noncash_hideed').attr('hidden', 'hidden');
            } else if ($(this).val() == 'noncash') {
                $('#noncash_hideed').removeAttr('hidden');
                $('#bank_hideed').attr('hidden', 'hidden');
            } else {
                $('#bank_hideed, #noncash_hideed').attr('hidden', 'hidden');
            }
        })
    
        var user_id;
        $(document).on('click', '.donat', function() {
            user_id = $(this).attr('id');
            console.log(user_id);


            $.ajax({
                url: "offdon/" + user_id,
                beforeSend: function() {
                    if (confirm('Apakah anda yakin ingin Mengaktifkan / Menonaktifkan Donatur ini?')) {
                        toastr.warning('Memproses....')
                    }
                },
                success: function(data) {
                    setTimeout(function() {
                        //  $('#confirmModal').modal('hide');
                        // $('#user_table').DataTable().ajax.reload();
                        $('#user_table').DataTable().ajax.reload(null, false);
                        toastr.success('Berhasil')
                    }, 2000);
                }
            })


        });
        var id;
        $(document).on('click', '.delete', function() {
            id = $(this).attr('id');
            console.log(id);


            if (confirm('Apakah anda yakin ingin Menghapus Donatur ini?')) {
                $.ajax({
                    url: "donatur/delete/" + id,
                    beforeSend: function() {
                        toastr.warning('Memproses....')
                    },
                    success: function(data) {
                        setTimeout(function() {
                            //  $('#confirmModal').modal('hide');
                            // $('#user_table').DataTable().ajax.reload();
                            $('#user_table').DataTable().ajax.reload(null, false);
                            toastr.success('Berhasil')
                        }, 2000);
                    }
                })

            }

        });

        $('.cek').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.cek1').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.cek2').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.ceks').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });
        
        $('.cekl').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });
    });
</script>
@endif

@if(Request::segment(1) == 'penerimaan' || Request::segment(2) == 'penerimaan')
<script>
    $(document).ready(function() {
        $('#user_table thead tr')
            .clone(true)
            .addClass('filters')
            .appendTo('#user_table thead');
            
        $('#user_table').on('dblclick', 'tr', function(){
            var oTable = $('#user_table'). dataTable();
            var oData = oTable.fnGetData(this);
            var id = oData.id;
            
            $('#modals').modal('show');
            var body = '';
            var footer = '';
            
            $.ajax({
                url: "penerimaanBy/" + id,
                dataType: "json",
                success: function(data) {
                    
                    if(data.bukti != null){
                        var bukti = `<a href="https://kilauindonesia.org/kilau/gambarUpload/` + data.bukti + `" class="btn btn-primary btn-xxs" target="_blank">Lihat Foto</a>`;
                    }else{
                        var bukti = `<span class="badge badge-primary badge-xxs light" disabled>Lihat Foto</span>`;
                    }
                    
                    var number_string = data.jumlah.toString(),
                        sisa = number_string.length % 3,
                        rupiah = number_string.substr(0, sisa),
                        ribuan = number_string.substr(sisa).match(/\d{3}/g);

                    if (ribuan) {
                        separator = sisa ? '.' : '';
                        rupiah += separator + ribuan.join('.');
                    }

                    
                    body = `<div class="mb-3 row">
                                <label class="col-sm-4 ">Tanggal</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+data.tanggal+`</text>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">User Input</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+data.user_insert+`</text>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">Jenis Transaksi</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+data.akun+`</text>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">Nominal</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                    <div style="display: block" id="nom_hide">
                                        <text>`+rupiah+`</text>
                                   </div>
                                   <div style="display: none" id="input_hide">
                                        <input class="form-control" id="ednom" name="ednom" placeholder="`+data.jumlah+`"/>
                                   </div>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">Keterangan</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                    <div style="display: block" id="ket_hide">
                                       <text>`+data.ket_penerimaan+`</text>
                                    </div>
                                    <div style="display: none" id="text_hide">
                                       <textarea id="edket" name="edket" class="form-control" height="200px">`+data.ket_penerimaan+`</textarea>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-4 ">Bukti</label>
                                <label class="col-sm-1 ">:</label>
                                <div class="col-sm-6">
                                   <text>`+bukti+`</text>
                                </div>
                            </div>`
                    
                    $('#boday').html(body)
                    $('#footay').html(footer)
                }
            })
            
            
        });

        load_data();

        function load_data() {
            var via = $('#via').val();
            var dari = $('#dari').val();
            var sampai = $('#sampai').val();
            var kantt = $('#kantt').val();
            $('#user_table').DataTable({

                //   processing: true,
                serverSide: true,
                scrollX: true,
                language: {
                    paginate: {
                        next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
                        previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>'
                    }
                },

                ajax: {
                    url: "penerimaan",
                    data: {
                        via: via,
                        dari: dari,
                        sampai: sampai,
                        kantt: kantt
                    }
                },
                columns: [{
                        data: 'tanggal',
                        name: 'tanggal',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'akun',
                        name: 'akun'
                    },
                    {
                        data: 'ket_penerimaan',
                        name: 'ket_penerimaan'
                    },
                    {
                        data: 'qty',
                        name: 'qty'
                    },
                    {
                        data: 'jml',
                        name: 'jml'
                    },
                    {
                        data: 'user_i',
                        name: 'user_i'
                    },
                    {
                        data: 'user_a',
                        name: 'user_a'
                    },
                    {
                        data: 'donaturr',
                        name: 'donaturr'
                    },
                    {
                        data: 'program',
                        name: 'program'
                    },
                    {
                        data: 'kantorr',
                        name: 'kantorr',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'coa_debet',
                        name: 'coa_debet',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'coa_kredit',
                        name: 'coa_kredit',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'apr',
                        name: 'apr',
                        orderable: false,
                        searchable: false
                    },
                    // { data: 'action', name: 'action', orderable: false, searchable: false },
                    // { data: 'wow', name: 'wow', orderable: false, searchable: false },
                    // { data: 'hapus', name: 'hapus', orderable: false, searchable: false },
                ],
                dom: 'lBfrtip',
                buttons: [{
                    extend: 'collection',

                    text: 'Export',
                    buttons: [{
                            extend: 'copy',
                            title: 'Data Donatur',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 12]
                            }
                        },
                        {
                            extend: 'excel',
                            title: 'Data Donatur',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 12]
                            }
                        },
                        {
                            extend: 'pdf',
                            title: 'Data Donatur',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 12]
                            }
                        },
                        {
                            extend: 'print',
                            title: 'Data Donatur',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 12]
                            }
                        },
                    ],
                    // className: "btn btn-sm btn-primary",
                }],
                lengthMenu: [
                    [10, 25, 50, 100, 500, -1],
                    [10, 25, 50, 100, 500, "All"]
                ],
                createdRow: function(row, data, index) {
                    $('td', row).eq(10).css('display', 'none'); // 6 is index of column
                },
                order: [
                    [10, "desc"]
                ],
                orderCellsTop: true,
                fixedHeader: true,
                initComplete: function() {
                    var api = this.api();

                    // For each column
                    api.columns()
                        .eq(0)
                        .each(function(colIdx) {
                            // Set the header cell to contain the input element
                            var cell = $('.filters th').eq(
                                $(api.column(colIdx).header()).index()
                            );
                            var title = $(cell).text();
                            $(cell).html('<input type="text" placeholder="' + title + '" />');

                            // On every keypress in this input
                            $(
                                    'input',
                                    $('.filters th').eq($(api.column(colIdx).header()).index())
                                )
                                .off('keyup change')
                                .on('keyup change', function(e) {
                                    e.stopPropagation();

                                    // Get the search value
                                    $(this).attr('title', $(this).val());
                                    var regexr = '({search})'; //$(this).parents('th').find('select').val();

                                    var cursorPosition = this.selectionStart;
                                    // Search the column for that value
                                    api
                                        .column(colIdx)
                                        .search(
                                            this.value != '' ?
                                            regexr.replace('{search}', '(((' + this.value + ')))') :
                                            '',
                                            this.value != '',
                                            this.value == ''
                                        )
                                        .draw();

                                    $(this)
                                        .focus()[0]
                                        .setSelectionRange(cursorPosition, cursorPosition);
                                });
                        });
                },
            });
        }

        //   $('.js-example-basic-single').select2();

        $('.filtt').on('click', function(){
            if($('#advsrc').val() == 'tutup'){
                 $('.cari input').css('display','table');
                //  $('#user_table thead tr')
                //     .clone(true)
                //     .addClass('filters')
                //     .appendTo('#user_table thead');
                 $('#advsrc').val('buka');
            }else{
                 $('thead input').css('display','none');
                  $('#user_table thead').removeClass('filters')
                 $('#advsrc').val('tutup');
            }
        });

        $(document).on('click', '.edd', function() {
            var id = $(this).attr('id');
            console.log(id);
            $.ajax({
                url: "riwayatdonasi/" + id,
                dataType: "json",
                success: function(data) {
                    window.location.href = "transaksi";
                    console.log(data);
                    $('#id_hidden').val(id);
                }
            })
        })

        var firstEmptySelect3 = false;

        function formatSelect3(result) {
            if (!result.id) {
                if (firstEmptySelect3) {
                    firstEmptySelect3 = false;
                    return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                }
            }else{
                var isi = '';
                
                if (result.parent == 'y') {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                        '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                    '</div>';
                } else {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4">' + result.coa + '</div>' +
                        '<div class="col-lg-8">' + result.nama_coa + '</div>'
                    '</div>';
                }
    
                return isi;
            }
            
        }
        
        function formatResult3(result) {
            if (!result.id) {
                if (firstEmptySelect3) {
                    return '<div class="row">' +
                            '<div class="col-lg-11"><b>Nama Akun</b></div>'
                        '</div>';
                }
            }else{
                
    
                var isi = '';
                
                if (result.parent == 'y') {
                    isi = '<div class="row">' +
                        '<div class="col-lg-11"><b>' + result.nama_coa + '</b></div>'
                    '</div>';
                } else {
                    isi = '<div class="row">' +
                        '<div class="col-lg-11">' + result.nama_coa + '</div>'
                    '</div>';
                }
                return isi;
            }
        }

        function matcher3(query, option) {
            firstEmptySelect3 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }
        $.ajax({
            url: 'getcoapenerimaan',
            type: 'GET',
            success: function(response) {
                //  console.log (response)
                $('#jenis_t').select2({
                    data: response,
                    width: '100%',
                    templateResult: formatSelect3,
                    templateSelection: formatResult3,
                    escapeMarkup: function(m) {
                        return m;
                    },
                    matcher: matcher3

                })
            }
        });

        var firstEmptySelect4 = true;

        function formatSelect4(result) {
            if (!result.id) {
                if (firstEmptySelect4) {
                    // console.log('showing row');
                    firstEmptySelect4 = false;
                    return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                } else {
                    // console.log('skipping row');
                    return false;
                }
                console.log('result');
                // console.log(result);
            }

            var isi = '';
            // console.log(result.parent);
            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                    '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-4">' + result.coa + '</div>' +
                    '<div class="col-lg-8">' + result.nama_coa + '</div>'
                '</div>';
            }

            return isi;
        }

        function matcher4(query, option) {
            firstEmptySelect4 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }
        $.ajax({
            url: 'getcoapersediaan',
            type: 'GET',
            success: function(response) {
                //  console.log (response)
                $('.js-example-basic-singlex').select2({
                    data: response,
                    width: '100%',
                    templateResult: formatSelect4,
                    templateSelection: formatSelect4,
                    escapeMarkup: function(m) {
                        return m;
                    },
                    matcher: matcher4

                })
            }
        });

        var arr = [];

        $('#add').on('click', function() {
            var kntr = document.forms["sample_form"]["kantor"].value;
            var jns_t = document.forms["sample_form"]["jenis_t"].value;
            var nmnl = document.forms["sample_form"]["nominal"].value;
            var keter = document.forms["sample_form"]["ket"].value;
            var bayar = document.forms["sample_form"]["via_bayar"].value;
            var bank = document.forms["sample_form"]["bank"].value;
            var noncash = document.forms["sample_form"]["non_cash"].value;
            // var ban = document.forms["sample_form"]["id_bank"].value;
            if (bayar == "") {
                toastr.warning('Pilih Via Pembayaran');
                return false;
            } else if (bayar == "bank" && bank == "") {
                toastr.warning('Pembayaan via bank kosong harap diisi !');
                return false;
            } else if (bayar == "noncash" && noncash == "") {
                toastr.warning('Pembayaan via non cash kosong harap diisi !');
                return false;
            } else if (kntr == "") {
                toastr.warning('Pilih Kantor');
                return false;
            } else if (jenis_t == "") {
                toastr.warning('Pilih Jenis Transaksi');
                return false;
            } else if (nmnl == "") {
                toastr.warning('Pilih Nominal');
                return false;
            }

            var prog = $('option:selected', '.js-example-basic-single').text();
            var ex = prog.split("-");
            var level = ex[1];

            var id_kantor = $('#kantor').val();
            var pembayaran = $('#via_bayar').val();
            var kantor = $('#kantor').find("option:selected").attr('data-value');
            var jenis_trans = level;
            // var program = $('#program').find("option:selected").attr('data-value');
            var coa = $('.js-example-basic-single').select2("val");
            var user_input = $('#user_input').val();
            // var id_program = $('#tgl_now').val();
            // var id_bank = $('#id_bank').val();
            // var bukti = $('#base64').val();
            // var namafile = $('#nama_file').val();
            var bank = $('#bank').val();
            var non_cash = $('.js-example-basic-singlex').select2("val");
            var tgl = $('#tgl_now').val();
            var qty = 1;
            var keterangan = $('#ket').val();
            var nominal = $('#nominal').val();
            var tgl = $('#tgl_now').val();
            
            

            arr.push({
                id_kantor: id_kantor,
                coa: coa,
                kantor: kantor,
                bank: bank,
                non_cash: non_cash,
                jenis_trans: jenis_trans,
                pembayaran: pembayaran,
                user_input: user_input,
                keterangan: keterangan,
                nominal: nominal,
                tgl: tgl,
                qty: qty,
            });

            $('#ket').val('');
            $('#nominal').val('');
            $("#jenis_t").val('').trigger('change');
            // console.log(arr);
            load_array()

        });

        $('#tambah').click(function() {
            $('#smpn').removeAttr('disabled');
            $('#sample_form')[0].reset();
        });

        $('#ket').on('click', function() {
            var prog = $('option:selected', '.js-example-basic-single').text();
            var ex = prog.split("-");
            console.log(ex[1]);
            var level = ex[1];

            $("#ket").val(level).trigger('change');
        })

        $('.js-example-basic-single').on('change', function() {

            var prog = $('option:selected', '.js-example-basic-single').text();

            var ex_prog = prog.split("-");

            if (ex_prog[0] == "y") {
                $("#jenis_t").val('').trigger('change');
                toastr.warning('Pilih Transaksi jenis Child');
                return false;
            }

        })

        load_array()

        function load_array() {
            console.log(arr);
            var table = '';
            var foot = '';
            var tots = 0;
            var nom = 0;
            var totall = 0;
            var totalo = 0;
            var tot = arr.length;
            if (tot > 0) {
                for (var i = 0; i < tot; i++) {
                    nom = Number(arr[i].nominal.replace(/\./g, ""));
                    tots += Number(arr[i].nominal.replace(/\./g, ""));
                    totall = nom * arr[i].qty;

                    var number_string = totall.toString(),
                        sisa = number_string.length % 3,
                        rupiah = number_string.substr(0, sisa),
                        ribuan = number_string.substr(sisa).match(/\d{3}/g);

                    if (ribuan) {
                        separator = sisa ? '.' : '';
                        rupiah += separator + ribuan.join('.');
                    }

                    totalo = tots * arr[i].qty;
                    // totalo = ;
                    table += `<tr><td>` + arr[i].coa + `</td><td>` + arr[i].jenis_trans + `</td><td>` + arr[i].qty + `</td><td>` + arr[i].nominal + `</td><td>` + rupiah + `</td><td>` + arr[i].keterangan + `</td><td>` + arr[i].kantor + `</td><td><a class="hps btn btn-danger btn-sm" id="` + i + `">Hapus</a></td></tr>`;
                }

                var number_string = totalo.toString(),
                    sisa = number_string.length % 3,
                    rupiah = number_string.substr(0, sisa),
                    ribuan = number_string.substr(sisa).match(/\d{3}/g);

                if (ribuan) {
                    separator = sisa ? '.' : '';
                    rupiah += separator + ribuan.join('.');
                }
                // console.log(jum);
                foot = `<tr> <td></td> <td><b>Total :</b></td> <td></td> <td></td> <td><b>` + rupiah + `</b></td> <td></td> <td></td> <td></td></tr>`;
            }

            $('#table').html(table);
            $('#foot').html(foot);
        }

        $('#sample_form').on('submit', function(event) {

            event.preventDefault();

            $.ajax({
                url: "post_add",
                method: "POST",
                data: {
                    arr: arr
                },
                dataType: "json",
                success: function(data) {
                    $('.blokkk').attr('disabled', true);
                    $('#sample_form')[0].reset();
                    // $('#action_prog').val('add');
                    $('#table tr').remove();
                    $('#foot tr').remove();
                    $('#user_table').DataTable().ajax.reload();
                    $('#modal-default1').hide();
                    $('.modal-backdrop').remove();
                    toastr.success('Berhasil');
                }
            });
        });

        $(document).on('click', '.hps', function() {
            // $('#hps_data').val(this);
            if (confirm('Apakah anda Ingin Menghapus Data Ini ??')) {
                arr.splice($(this).attr('id'), 1);
                load_array();
            }
        })

        $('#via_bayar').on('change', function() {
            if ($(this).val() == 'bank') {
                $('#bank_hide').removeAttr('hidden');
                $('#noncash_hide').attr('hidden', 'hidden');
            } else if ($(this).val() == 'noncash') {
                $('#noncash_hide').removeAttr('hidden');
                $('#bank_hide').attr('hidden', 'hidden');
            } else {
                $('#bank_hide, #noncash_hide').attr('hidden', 'hidden');
            }
        })

        var user_id;
        $(document).on('click', '.donat', function() {
            user_id = $(this).attr('id');
            console.log(user_id);


            $.ajax({
                url: "offdon/" + user_id,
                beforeSend: function() {
                    if (confirm('Apakah anda yakin ingin Mengaktifkan / Menonaktifkan Donatur ini?')) {
                        toastr.warning('Memproses....')
                    }
                },
                success: function(data) {
                    setTimeout(function() {
                        //  $('#confirmModal').modal('hide');
                        $('#user_table').DataTable().ajax.reload();
                        toastr.success('Berhasil')
                    }, 2000);
                }
            })


        });
        var id;
        $(document).on('click', '.delete', function() {
            id = $(this).attr('id');
            console.log(id);


            if (confirm('Apakah anda yakin ingin Menghapus Donatur ini?')) {
                $.ajax({
                    url: "donatur/delete/" + id,
                    beforeSend: function() {
                        toastr.warning('Memproses....')
                    },
                    success: function(data) {
                        setTimeout(function() {
                            //  $('#confirmModal').modal('hide');
                            $('#user_table').DataTable().ajax.reload();
                            toastr.success('Berhasil')
                        }, 2000);
                    }
                })

            }

        });

        $('.cek').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.cek1').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.cek2').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });
    });
</script>
@endif

@if(Request::segment(1) == 'penyaluran')
<script>
    var firstEmptySelect = false;

    function formatSelect(result) {
        if (!result.id) {
            if (firstEmptySelect) {
                // console.log('showing row');
                // firstEmptySelect = false;
                return '<div class="row">' +
                    '<div class="col-lg-11"><b>nama</b></div>' +
                    '</div>';
            }
        }

        var isi = '';
        // console.log(result.parent);
        isi = '<div class="row">' +
            '<div class="col-lg-11">' + result.nama + '</div>' +
            '</div>';


        return isi;
    }

    function formatResult(result) {
        if (!result.id) {
            if (firstEmptySelect) {
                // console.log('showing row');
                firstEmptySelect = false;
                return '<div class="row">' +
                    '<div class="col-lg-4"><b>Nama PM</b></div>'
                '</div>';
            } else {
                return false;
            }
        }

        var isi = '';
        isi = '<div class="row">' +
            '<div class="col-lg-8">' + result.nama + '</div>'
        '</div>';
        return isi;
    }

    function matcher(query, option) {
        firstEmptySelect = true;
        if (!query.term) {
            return option;
        }
        var has = true;
        var words = query.term.toUpperCase().split(" ");
        for (var i = 0; i < words.length; i++) {
            var word = words[i];
            has = has && (option.text.toUpperCase().indexOf(word) >= 0);
        }
        if (has) return option;
        return false;
    }

    function rupiah(objek) {
        separator = ".";
        a = objek.value;
        b = a.replace(/[^\d]/g, "");
        c = "";
        panjang = b.length;
        j = 0;
        for (i = panjang; i > 0; i--) {
            j = j + 1;
            if (((j % 3) == 1) && (j != 1)) {
                c = b.substr(i - 1, 1) + separator + c;
            } else {
                c = b.substr(i - 1, 1) + c;
            }
        }
        if (c <= 0) {
            objek.value = '';
        } else {
            objek.value = c;
        }

        var input = document.getElementById("nominal").value.replace(/\./g, "");

    }


    $(document).ready(function() {

        // document.getElementsByClassName("filters").style.display = "none";

        $('.select2').select2({
            minimumInputLength: 3,
            dropdownCssClass: 'droppp',
            //   allowClear: true,
            placeholder: 'masukkan Nama Donatur',
            templateResult: formatSelect,
            templateSelection: formatResult,
            escapeMarkup: function(m) {
                return m;
            },
            matcher: matcher,
            ajax: {
                dataType: 'json',
                url: "nama_pm",
                delay: 800,
                data: function(params) {
                    return {
                        search: params.term
                    }
                },
                processResults: function(data) {
                    return {
                        results: data
                    };
                }
            }
        });

        $('#nama_pm').on('change', function() {
            var id = $('#nama_pm').val();
            // console.log(id)
            $.ajax({
                url: 'get_info_pm/' + id,
                method: 'GET',
                dataType: "json",
                success: function(data) {
                    console.log(data);
                    // $('#id_pm').val(data.id);
                    $('#hppm').val(data.hp);
                    $('#idpm').val(data.idtot);
                    $('#emailpm').val(data.email);
                    $('#alamat_pm').val(data.alay);
                    $('#pj').val(data.nama_pj);
                    $('#asnaf').val(data.asnaf);
                    $('#kantor_pm').val(data.unit);
                    $('#koordinat_pm').val(data.latitude + `,` + data.longitude);
                }
            })
            // document.getElementById("edit").style.display = "block";
        })



        $('#user_table thead tr')
            .clone(true)
            .addClass('filters')
            .appendTo('#user_table thead');

        load_data();

        function load_data() {
            var via = $('#via').val();

            $('#user_table').DataTable({

                //   processing: true,
                serverSide: true,
                // scrollX: true,
                language: {
                    paginate: {
                        next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
                        previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>'
                    }
                },
                ajax: {
                    url: "penyaluran",
                    data: {
                        via: via
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'nama_pm',
                        name: 'nama_pm'
                    },
                    {
                        data: 'jenis_transaksi',
                        name: 'jenis_transaksi'
                    },
                    {
                        data: 'jml',
                        name: 'jml'
                    },
                    {
                        data: 'tanggal_mohon',
                        name: 'tanggal_mohon'
                    },
                    {
                        data: 'tanggal_salur',
                        name: 'tanggal_salur'
                    },
                    {
                        data: 'kantorr',
                        name: 'kantorr',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                ],
                dom: 'lBfrtip',
                buttons: [{
                    extend: 'collection',

                    text: 'Export',
                    buttons: [{
                            extend: 'copy',
                            title: 'Data Donatur',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6]
                            }
                        },
                        {
                            extend: 'excel',
                            title: 'Data Donatur',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6]
                            }
                        },
                        {
                            extend: 'pdf',
                            title: 'Data Donatur',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6]
                            }
                        },
                        {
                            extend: 'print',
                            title: 'Data Donatur',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6]
                            }
                        },
                    ],
                    // className: "btn btn-sm btn-primary",
                }],
                lengthMenu: [
                    [10, 25, 50, 100, 500, -1],
                    [10, 25, 50, 100, 500, "All"]
                ],
                createdRow: function(row, data, index) {
                    $('td', row).eq(7).css('display', 'none'); // 6 is index of column
                },
                order: [
                    [7, "desc"]
                ],
                orderCellsTop: true,
                fixedHeader: true,
                initComplete: function() {
                    var api = this.api();

                    // For each column
                    api.columns()
                        .eq(0)
                        .each(function(colIdx) {
                            // Set the header cell to contain the input element
                            var cell = $('.filters th').eq(
                                $(api.column(colIdx).header()).index()
                            );
                            var title = $(cell).text();
                            $(cell).html('<input type="text" placeholder="' + title + '" />');

                            // On every keypress in this input
                            $(
                                    'input',
                                    $('.filters th').eq($(api.column(colIdx).header()).index())
                                )
                                .off('keyup change')
                                .on('keyup change', function(e) {
                                    e.stopPropagation();

                                    // Get the search value
                                    $(this).attr('title', $(this).val());
                                    var regexr = '({search})'; //$(this).parents('th').find('select').val();

                                    var cursorPosition = this.selectionStart;
                                    // Search the column for that value
                                    api
                                        .column(colIdx)
                                        .search(
                                            this.value != '' ?
                                            regexr.replace('{search}', '(((' + this.value + ')))') :
                                            '',
                                            this.value != '',
                                            this.value == ''
                                        )
                                        .draw();

                                    $(this)
                                        .focus()[0]
                                        .setSelectionRange(cursorPosition, cursorPosition);
                                });
                        });
                },
            });
        }


        $('.filtt').on('click', function() {
            if ($('#advsrc').val() == 'tutup') {
                $('.cari input').css('display', 'block');
                $('#advsrc').val('buka');
            } else {
                $('thead input').css('display', 'none');
                $('#advsrc').val('tutup');
            }
        });

        $(document).on('click', '.edd', function() {
            var id = $(this).attr('id');
            console.log(id);
            $.ajax({
                url: "riwayatdonasi/" + id,
                dataType: "json",
                success: function(data) {
                    window.location.href = "transaksi/";
                    console.log(data);
                    $('#id_hidden').val(id);
                }
            })
        })

        var firstEmptySelect3 = false;

        function formatSelect3(result) {
            if (!result.id) {
                if (firstEmptySelect3) {
                    // console.log('showing row');
                    firstEmptySelect3 = false;
                    return '<div class="row">' +
                        '<div class="col-lg-6"><b>Program</b></div>' +
                        '<div class="col-lg-6"><b>Sumber Dana</b></div>'
                    '</div>';
                }
            }else{

                    var isi = '';
                    // console.log(result.parent);
                    if (result.parent == 'y') {
                        isi = '<div class="row">' +
                            '<div class="col-lg-6"><b>' + result.program + '</b></div>' +
                            '<div class="col-lg-6"><b>' + result.sumberdana + '</b></div>'
                        '</div>';
                    } else {
                        isi = '<div class="row">' +
                            '<div class="col-lg-6">' + result.program + '</div>' +
                            '<div class="col-lg-6">' + result.sumberdana + '</div>'
                        '</div>';
                    }
        
                    return isi;
            }
        }
        
        function formatResult3(result) {
            if (!result.id) {
                if (firstEmptySelect3) {
                    return '<div class="row">' +
                            '<div class="col-lg-11"><b>Program</b></div>'
                        '</div>';
                }
            }else{
    
                var isi = '';
                
                if (result.parent == 'y') {
                    isi = '<div class="row">' +
                        '<div class="col-lg-11"><b>' + result.program + '</b></div>'
                    '</div>';
                } else {
                    isi = '<div class="row">' +
                        '<div class="col-lg-11">' + result.program + '</div>'
                    '</div>';
                }
                return isi;
            }
        }

        function matcher3(query, option) {
            firstEmptySelect3 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }
        $.ajax({
            url: 'get_program_penyaluran',
            type: 'GET',
            success: function(response) {
                console.log(response)
                $('#jenis_t').select2({
                    data: response,
                    width: '100%',
                    templateResult: formatSelect3,
                    templateSelection: formatResult3,
                    escapeMarkup: function(m) {
                        return m;
                    },
                    matcher: matcher3

                })
            }
        });

        var firstEmptySelect4 = true;

        function formatSelect4(result) {
            if (!result.id) {
                if (firstEmptySelect4) {
                    // console.log('showing row');
                    firstEmptySelect4 = false;
                    return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                } else {
                    // console.log('skipping row');
                    return false;
                }
                console.log('result');
                // console.log(result);
            }

            var isi = '';
            // console.log(result.parent);
            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                    '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-4">' + result.coa + '</div>' +
                    '<div class="col-lg-8">' + result.nama_coa + '</div>'
                '</div>';
            }

            return isi;
        }

        function matcher4(query, option) {
            firstEmptySelect4 = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }
        $.ajax({
            url: 'getcoapersediaan',
            type: 'GET',
            success: function(response) {
                //  console.log (response)
                $('.js-example-basic-singlex').select2({
                    data: response,
                    width: '100%',
                    templateResult: formatSelect4,
                    templateSelection: formatSelect4,
                    escapeMarkup: function(m) {
                        return m;
                    },
                    matcher: matcher4

                })
            }
        });

        var arr = [];

        $('#add').on('click', function() {
            var kntr = document.forms["sample_form"]["kantor"].value;
            var jns_t = document.forms["sample_form"]["jenis_t"].value;
            var nmnl = document.forms["sample_form"]["nominal"].value;
            var pm = document.forms["sample_form"]["nama_pm"].value;
            var keter = document.forms["sample_form"]["ket"].value;
            var bayar = document.forms["sample_form"]["via_per"].value;
            var bank = document.forms["sample_form"]["bank"].value;
            var noncash = document.forms["sample_form"]["non_cash"].value;
            // var ban = document.forms["sample_form"]["id_bank"].value;
            if (bayar == "") {
                toastr.warning('Pilih Via Pembayaran');
                return false;
            } else if (bayar == "bank" && bank == "") {
                toastr.warning('Pembayaan via bank kosong harap diisi !');
                return false;
            } else if (bayar == "noncash" && noncash == "") {
                toastr.warning('Pembayaan via non cash kosong harap diisi !');
                return false;
            } else if (kntr == "") {
                toastr.warning('Pilih Kantor');
                return false;
            } else if (jenis_t == "") {
                toastr.warning('Pilih Jenis Transaksi');
                return false;
            } else if (nmnl == "") {
                toastr.warning('Pilih Nominal');
                return false;
            } else if (keter == "") {
                toastr.warning('Keterangan harap diisi !');
                return false;
            } else if (pm == "") {
                toastr.warning('PM harap diisi !');
                return false;
            }

            var prog = $('option:selected', '.js-example-basic-single').text();
            var ex = prog.split("-");
            var level = ex[2];
            var via_per = $('#via_per').val();
            var tgl_per = $('#tgl_per').val();
            var id_kantor = $('#kantor').val();
            var total = $('#total').val();
            var idpm = $('#idpm').val();
            var pembayaran = $('#via_cair').val();
            var kantor = $('#kantor').find("option:selected").attr('data-value');
            var jenis_trans = level;
            var nama_pm = $('option:selected', '.select2').text();
            // var program = $('#program').find("option:selected").attr('data-value');
            var coa = $('.js-example-basic-single').select2("val");
            var user_input = $('#user_input').val();
            var bank = $('#bank').val();
            var non_cash = $('.js-example-basic-singlex').select2("val");
            var tgl = $('#tgl_now').val();
            var qty = $('#qty').val();
            var keterangan = $('#ket').val();
            var nominal = $('#nominal').val();
            var tgl = $('#tgl_now').val();

            arr.push({
                id_kantor: id_kantor,
                tgl_per: tgl_per,
                idpm: idpm,
                coa: coa,
                nama_pm: nama_pm,
                via_per: via_per,
                via_per: via_per,
                kantor: kantor,
                bank: bank,
                non_cash: non_cash,
                jenis_trans: jenis_trans,
                pembayaran: pembayaran,
                user_input: user_input,
                keterangan: keterangan,
                nominal: nominal,
                tgl: tgl,
                qty: qty,
                total: total
            });

            $('#ket').val('');
            $('#nominal').val('');
            $('#total').val('');
            $('#qty').val('');
            $("#jenis_t").val('').trigger('change');
            // $('#donatur').attr("disabled", true); 
            // document.getElementById("donatur").readOnly = true;
            // $('#donatur').attr('readonly', true)
            // console.log(formData);
            console.log(arr);
            // $('#user_table').DataTable().destroy();
            load_array()

        });

        $('#tambah').click(function() {
            $('#smpn').removeAttr('disabled');
            $('#sample_form')[0].reset();
            $("#nama_pm").val('').trigger('change');
            $("#alamat_pm").html('');
            // $("#coa_individu").val('').trigger('change');
            // $("#coa_entitas").val('').trigger('change');

        });

        $('#ket').on('click', function() {
            var prog = $('option:selected', '.js-example-basic-single').text();
            var ex = prog.split("-");
            var nama_pm = $('option:selected', '.select2').text();
            var asnaf = $('#asnaf').val();
            console.log(ex[2]);
            var level = 'an: ' + nama_pm + ' | ' + ex[2] + ' | ' + asnaf;

            $("#ket").val(level).trigger('change');
        })

        $('#total').on('click', function() {
            var qty = $('#qty').val();
            var nominal = $('#nominal').val();
            var qq = Number(nominal.replace(/\./g, ""));
            var ex = qty * qq;
            console.log(ex);
            var number_string = ex.toString(),
                sisa = number_string.length % 3,
                rupiah = number_string.substr(0, sisa),
                ribuan = number_string.substr(sisa).match(/\d{3}/g);

            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            var level = rupiah;

            $("#total").val(level).trigger('change');
        })

        $('.js-example-basic-single').on('change', function() {

            var prog = $('option:selected', '.js-example-basic-single').text();

            var ex_prog = prog.split("-");

            if (ex_prog[0] == "y") {
                $("#jenis_t").val('').trigger('change');
                toastr.warning('Pilih Transaksi jenis Child');
                return false;
            }

        })

        load_array()

        function load_array() {
            console.log(arr);
            var table = '';
            var foot = '';
            var tots = 0;
            var nom = 0;
            var totall = 0;
            var totalo = 0;
            var tot = arr.length;
            if (tot > 0) {
                for (var i = 0; i < tot; i++) {
                    nom = Number(arr[i].nominal.replace(/\./g, ""));
                    tots += Number(arr[i].nominal.replace(/\./g, ""));
                    totall = nom * arr[i].qty;

                    var number_string = totall.toString(),
                        sisa = number_string.length % 3,
                        rupiah = number_string.substr(0, sisa),
                        ribuan = number_string.substr(sisa).match(/\d{3}/g);

                    if (ribuan) {
                        separator = sisa ? '.' : '';
                        rupiah += separator + ribuan.join('.');
                    }

                    totalo = tots * arr[i].qty;
                    // totalo = ;
                    table += `<tr><td>` + arr[i].jenis_trans + `</td><td>` + arr[i].qty + `</td><td>` + arr[i].nominal + `</td><td>` + rupiah + `</td><td>` + arr[i].keterangan + `</td><td>` + arr[i].kantor + `</td><td><a class="hps btn btn-danger btn-sm" id="` + i + `">Hapus</a></td></tr>`;
                }

                var number_string = totalo.toString(),
                    sisa = number_string.length % 3,
                    rupiah = number_string.substr(0, sisa),
                    ribuan = number_string.substr(sisa).match(/\d{3}/g);

                if (ribuan) {
                    separator = sisa ? '.' : '';
                    rupiah += separator + ribuan.join('.');
                }
                // console.log(jum);
                foot = `<tr> <td><b>Total :</b></td> <td></td> <td></td> <td><b>` + rupiah + `</b></td> <td></td> <td></td> <td></td></tr>`;
            }



            $('#table').html(table);
            $('#foot').html(foot);
        }

        $('#sample_form').on('submit', function(event) {

            event.preventDefault();

            $.ajax({
                url: "post_penyaluran",
                method: "POST",
                data: {
                    arr: arr
                },
                dataType: "json",
                success: function(data) {
                    // $('.blokkk').attr('disabled', true);
                    $('#sample_form')[0].reset();
                    // $('#action_prog').val('add');
                    $('#table tr').remove();
                    $('#foot tr').remove();
                    $('#user_table').DataTable().ajax.reload();
                    $('#modal-default1').hide();
                    $('.modal-backdrop').remove();
                    toastr.success('Berhasil');
                }
            });
        });

        $(document).on('click', '.hps', function() {
            // $('#hps_data').val(this);
            if (confirm('Apakah anda Ingin Menghapus Data Ini ??')) {
                arr.splice($(this).attr('id'), 1);
                load_array();
                // console.log(arr);
            }
            //  toastr.warning($(this).attr('id'));
            // alert();
        })

        $('#via_cair').on('change', function() {
            if ($(this).val() == 'bank') {
                $('#bank_hide').removeAttr('hidden');
                $('#noncash_hide').attr('hidden', 'hidden');
            } else if ($(this).val() == 'noncash') {
                $('#noncash_hide').removeAttr('hidden');
                $('#bank_hide').attr('hidden', 'hidden');
            } else {
                $('#bank_hide, #noncash_hide').attr('hidden', 'hidden');
            }
        })

        var user_id;
        $(document).on('click', '.donat', function() {
            user_id = $(this).attr('id');
            console.log(user_id);


            $.ajax({
                url: "offdon/" + user_id,
                beforeSend: function() {
                    if (confirm('Apakah anda yakin ingin Mengaktifkan / Menonaktifkan Donatur ini?')) {
                        toastr.warning('Memproses....')
                    }
                },
                success: function(data) {
                    setTimeout(function() {
                        //  $('#confirmModal').modal('hide');
                        $('#user_table').DataTable().ajax.reload();
                        toastr.success('Berhasil')
                    }, 2000);
                }
            })


        });
        var id;
        $(document).on('click', '.delete', function() {
            id = $(this).attr('id');
            console.log(id);


            if (confirm('Apakah anda yakin ingin Menghapus Donatur ini?')) {
                $.ajax({
                    url: "donatur/delete/" + id,
                    beforeSend: function() {
                        toastr.warning('Memproses....')
                    },
                    success: function(data) {
                        setTimeout(function() {
                            //  $('#confirmModal').modal('hide');
                            $('#user_table').DataTable().ajax.reload();
                            toastr.success('Berhasil')
                        }, 2000);
                    }
                })

            }

        });

        $('.cek').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.cek1').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('.cek2').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });

    });
</script>
@endif

@if(Request::segment(1) == 'bank')
<script>
    function sele() {

        var id = $("#jenis_rek").find(':selected').attr('data-value');
        // console.log(id);
        var firstEmptySelect = true;

        function formatSelect(result) {
            //  console.log(result);
            // if(result.length != 0){
            var isi = '';


            if (!result.id) {
                if (firstEmptySelect) {
                    // console.log('showing row');
                    firstEmptySelect = false;
                    return '<div class="row">' +
                        '<div class="col-lg-4"><b>COA</b></div>' +
                        '<div class="col-lg-8"><b>Nama Akun</b></div>'
                    '</div>';
                } else {
                    // console.log('skipping row');
                    // isi = '';
                    return false;
                }
                //   return isi;
                // console.log(result);
            }


            // console.log(result.parent);

            if (result.parent == 'y') {
                isi = '<div class="row">' +
                    '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                    '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                '</div>';
            } else {
                isi = '<div class="row">' +
                    '<div class="col-lg-4">' + result.coa + '</div>' +
                    '<div class="col-lg-8">' + result.nama_coa + '</div>'
                '</div>';
            }

            return isi;


        }

        function matcher(query, option) {
            firstEmptySelect = true;
            if (!query.term) {
                return option;
            }
            var has = true;
            var words = query.term.toUpperCase().split(" ");
            for (var i = 0; i < words.length; i++) {
                var word = words[i];
                has = has && (option.text.toUpperCase().indexOf(word) >= 0);
            }
            if (has) return option;
            return false;
        }
        $.ajax({
            url: 'coa-bank/' + id,
            type: 'GET',
            success: function(response) {
                //  console.log (response)
                //  if(response.length != 0){

                $('.selectAccountDeal').select2({
                    data: response,
                    width: '100%',
                    templateResult: formatSelect,
                    templateSelection: formatSelect,
                    escapeMarkup: function(m) {
                        return m;
                    },
                    matcher: matcher,
                    // allowClear: true

                })
                //  }else{
                //      $('.selectAccountDeal').select2({
                //             })
                //  }
            }
        });
    }
    $(document).ready(function() {
        //  $('.select2').select2()
        $('#cek_coa').on('click', function() {

            if (document.getElementById('cek_coa').checked) {
                document.getElementById('coa').style.display = "block";
            } else {
                document.getElementById('coa').style.display = "none";
            }
        })

        $('#add').on('click', function() {
            $('#no_rek').val('');
            $('#nama_bank').val('');
            $('#id_kantor').val('');
            $('#jenis_rek').val('');
            document.getElementById("cek_coa").checked = false;
            $('#coa_cek').html('').select2({
                data: [{
                    id: '',
                    text: ''
                }]
            });
            document.getElementById('coa').style.display = "none";
            document.getElementById('ceklis_coa').style.display = "block";
            $('#action').val('add');
            $('#hidden_id').val('');
        });
        // selec()
        load_data();

        function load_data() {
            var id_kantor = $('#id_kantor').val();
            console.log(id_kantor);
            $('#user_table').DataTable({
                // processing: true,
                language: {
                    paginate: {
                        next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
                        previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>'
                    }
                },
                serverSide: true,
                ajax: {
                    url: "bank",
                    data: {
                        id_kantor: id_kantor
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'nama_bank',
                        name: 'nama_bank'
                    },
                    {
                        data: 'no_rek',
                        name: 'no_rek'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'action',
                        name: 'Kelola',
                        orderable: false
                    }
                ],

                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });

        }

        $('#jenis_rek').on('change', function() {
            $('#coa_cek').html('').select2({
                data: [{
                    id: '',
                    text: ''
                }]
            });
            sele();
        })

        $('#sample_form').on('submit', function(event) {
            event.preventDefault();
            var id_kantor = $('#id_kantor').val();
            var bank = $('#nama_bank').val();
            var norek = $('#no_rek').val();

            var formData = new FormData(this);
            formData.append('coa_parent', $("#jenis_rek").find(':selected').attr('data-value'));

            if (id_kantor == "") {
                toastr.warning("Pilih Kantor");
                return false;
            } else if (bank == "") {
                toastr.warning("Masukan Nama Bank");
                return false;
            } else if (norek == "") {
                toastr.warning("Masukan Nomor Rekening");
                return false;
            }

            var action_url = '';
            if ($('#action').val() == 'add') {
                action_url = "bank";
            }

            if ($('#action').val() == 'edit') {
                action_url = "bank/update";
            }

            $.ajax({
                url: action_url,
                method: "POST",
                data: formData,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                beforeSend: function() {
                    toastr.warning('Memprosess..')
                },
                success: function(data) {
                    var html = '';
                    if (data.errors) {
                        html = '<div class="alert alert-danger">';
                        for (var count = 0; count < data.errors.length; count++) {
                            html += '<p>' + data.errors[count] + '</p>';
                        }
                        html += '</div>';
                    }
                    if (data.success) {
                        // $('#simple-form')[0].reset();

                        $('#modal-default').hide();
                        $('.modal-backdrop').remove();
                        // load_data()
                        $('#action').val('add');
                        $('#hidden_id').val('');
                        $("body").removeClass("modal-open")
                        $('#user_table').DataTable().ajax.reload();
                        // $('#btnform').html('Tambah Bank');
                        toastr.success('Berhasil')
                    }
                }
            });
        });

        $(document).on('click', '.edit', function() {
            console.log('sda');
            var id = $(this).attr('id');
            $.ajax({
                url: "bank/edit/" + id,
                dataType: "json",
                success: function(data) {
                    $('#jenis_rek').val(data.result.jenis_rek);

                    // console.log($('#jenis_rek').val());
                    document.getElementById('ceklis_coa').style.display = "none";
                    // $('#coa_cek').val(data.result.id_coa).trigger('change');
                    sele();

                    // $('#coa_cek').select2('data', {id: data.result.id_coa, text: data.result.id_coa});
                    $('#nama_bank').val(data.result.nama_bank);
                    $('#no_rek').val(data.result.no_rek);
                    $('#id_kantor').val(data.result.id_kantor);
                    // document.getElementById("form-panel").style.display='block';
                    // $('#form').attr('data-value', 'yes');
                    $('#btnform').html('Edit Bank');
                    // $('#form').html('<i class="fa fa-minus"></i> Hide Form');
                    // $('#form').removeClass('btn-primary').addClass('btn-danger');
                    $('#action').val('edit');
                    $('#hidden_id').val(id);

                    document.getElementById('coa').style.display = "block";
                    $('#coa_cek').html('<option></option>').select2({
                        data: [{
                            id: data.result.id_coa,
                            text: data.result.id_coa
                        }]
                    });
                    $('#coa_cek').val(data.result.id_coa).trigger('change');
                    // console.log(data.result.id_coa);

                }
            })
        });

        var user_id;
        $(document).on('click', '.delete', function() {
            user_id = $(this).attr('id');
            console.log(user_id);

            if (confirm('Are you sure you want to delete this?')) {
                $.ajax({
                    url: "bank/" + user_id,
                    beforeSend: function() {
                        toastr.warning('Delete....')
                    },
                    success: function(data) {
                        setTimeout(function() {
                            //  $('#confirmModal').modal('hide');
                            $('#user_table').DataTable().ajax.reload();
                            toastr.success('Berhasil')
                        }, 2000);
                    }
                })
            }
        });
    });
</script>
@endif

@if(Request::segment(1) == 'coa')
<script>
    var columns = [{
            title: '',
            target: 0,
            className: 'treegrid-control',
            data: function(item) {
                if (item.children.length > 0) {
                    return '<span>+</span>';
                }
                return '';
            }
        },
        {
            title: 'COA',
            target: 1,
            data: function(item) {
                return item.coa;
            }
        },
        {
            title: 'Nama Akun',
            target: 2,
            data: function(item) {
                return item.nama_coa;
            }
        },
        {
            title: 'COA Parent',
            target: 3,
            data: function(item) {
                return item.coa_parent;
            }
        },
        {
            title: 'Level',
            target: 4,
            data: function(item) {
                return item.level;
            }
        },
        {
            title: 'Kelola',
            target: 5,
            data: function(item) {
                var btn = `<button id="` + item.id + `" class="edit btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modal-default" style="margin-right:10px"><i class="fa fa-edit"></i></button>`;
                btn += `<button id="` + item.id + `" class="delete btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>`
                return btn;
            }
        },
    ];
    
    function myFunction() {
      // Declare variables
      var input, filter, table, tr, td, i, txtValue;
      input = document.getElementById("myInput");
      filter = input.value.toUpperCase();
      table = document.getElementById("user_table");
      tr = table.getElementsByTagName("tr");
    
      // Loop through all table rows, and hide those who don't match the search query
      for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[1];
        if (td) {
          txtValue = td.textContent || td.innerText;
          if (txtValue.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
          } else {
            tr[i].style.display = "none";
          }
        }
      }
    }
    
    var $table = $('#user_table')

        $(function() {
            $table.bootstrapTable({
                // search: true,
                showToggle: true,
                url: "{{ url('coa_coa') }}",
                idField: 'id',
                showColumns: true,
                columns: [
                    {
                        field: 'coa',
                        title: 'COA'
                    },
                    // {
                    //     field: 'id_program',
                    //     title: 'id_program'
                    // },
                    {
                        field: 'nama_coa',
                        title: 'Akun',
                    },
                    {
                        field: 'coa_parent',
                        title: 'COA Parent',
                        // visible: false
                    },
                    {
                        field: 'level',
                        title: 'Level'
                    },
                    {
                        title: 'Kelola',
                        field: 'id',
                        formatter: (value, row, index) => {
                            // console.log(row);
                             var btn = `<button id="` + row.id + `" class="edit btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modal-default" style="margin-right:10px"><i class="fa fa-edit"></i></button>`;
                            btn += `<button id="` + row.id + `" class="delete btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>`
                            return btn;
                        }
                    },
                ],
                
                treeShowField: 'coa',
                parentIdField: 'id_parent',
                onPostBody: function() {
                    var columns = $table.bootstrapTable('getOptions').columns
    
                    if (columns && columns[0][0].visible) {
                        $table.treegrid({
                            treeColumn: 0,
                            onChange: function() {
                                $table.bootstrapTable('resetView')
                            }
                        })
                    }
                }
            })
        })   
    
    
    $(document).ready(function() {
        $('.select2').select2()
        sele();

        function sele() {

            var firstEmptySelect = true;

            function formatSelect(result) {
                if (!result.id) {
                    if (firstEmptySelect) {
                        // console.log('showing row');
                        firstEmptySelect = false;
                        return '<div class="row">' +
                            '<div class="col-lg-4"><b>COA</b></div>' +
                            '<div class="col-lg-8"><b>Nama Akun</b></div>'
                        '</div>';
                    } else {
                        // console.log('skipping row');
                        return false;
                    }
                    console.log('result');
                    // console.log(result);
                }

                var isi = '';
                // console.log(result.parent);
                if (result.parent == 'y') {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4"><b>' + result.coa + '</b></div>' +
                        '<div class="col-lg-8"><b>' + result.nama_coa + '</b></div>'
                    '</div>';
                } else {
                    isi = '<div class="row">' +
                        '<div class="col-lg-4">' + result.coa + '</div>' +
                        '<div class="col-lg-8">' + result.nama_coa + '</div>'
                    '</div>';
                }

                return isi;
            }

            function matcher(query, option) {
                firstEmptySelect = true;
                if (!query.term) {
                    return option;
                }
                var has = true;
                var words = query.term.toUpperCase().split(" ");
                for (var i = 0; i < words.length; i++) {
                    var word = words[i];
                    has = has && (option.text.toUpperCase().indexOf(word) >= 0);
                }
                if (has) return option;
                return false;
            }
            $.ajax({
                url: 'getcoa',
                type: 'GET',
                success: function(response) {
                    //  console.log (response)
                    $('#selectAccountDeal').select2({
                        data: response,
                        width: '100%',
                        templateResult: formatSelect,
                        templateSelection: formatSelect,
                        escapeMarkup: function(m) {
                            return m;
                        },
                        matcher: matcher

                    })
                }
            });
        }

        $('.js-example-basic-single').select2();
        // load_data();
        // function load_data(){

        // $('#user_table').DataTable({
        //     language: {
        //             paginate: {
        //                 next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
        //                 previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>'
        //             }
        //         },
        //     columns: columns,
        //     ajax: {
        //         url: "getcoba",
        //     },
            
        //     treeGrid: {
        //         left: 10,
        //         expandIcon: '<span style="cursor: pointer">+</span>',
        //         collapseIcon: '<span style="cursor: pointer">-</span>'
        //     }

        // });
        

        $('#selectAccountDeal').on('change', function() {

            var options = $('option:selected', this).val();
            var coa_par1 = $('option:selected', '#selectAccountDeal').text();
            if (coa_par1 != '') {
                var ex1 = coa_par1.split("-");
                var coa = ex1[1].split(".");
                var coa1 = coa[0].slice(0, 1);
                var coa2 = coa[0].slice(1, 3);
                // console.log(coa2);
                var level = 1;
                if (coa1 != 0 && coa2 == 00 && coa[1] == 00 && coa[2] == 000 && coa[3] == 000) {
                    level = 1;
                }
                if (coa1 != 0 && coa2 != 00 && coa[1] == 00 && coa[2] == 000 && coa[3] == 000) {
                    level = 2;
                }
                if (coa1 != 0 && coa2 != 00 && coa[1] != 00 && coa[2] == 000 && coa[3] == 000) {
                    level = 3;
                }
                if (coa1 != 0 && coa2 != 00 && coa[1] != 00 && coa[2] != 000 && coa[3] == 000) {
                    level = 4;
                }

            }


            $('#coa_parent').val(options);
            $("#level").val(level);
            console.log(coa_par1);
        })

        $(document).on('click', '.edit', function() {
            var id = $(this).attr('id');
            $.ajax({
                url: "coa/edit/" + id,
                dataType: "json",
                success: function(data) {
                    var group = data.result.grup;
                    // console.log(data.result);
                    $('#coa').val(data.result.coa);
                    $('#nama_coa').val(data.result.nama_coa);
                    // $("#id_parent").val(data.result.id_parent).trigger('change');
                    $("#selectAccountDeal").val(data.result.id_parent).trigger('change');
                    $('#multiple').val(group.split(",")).trigger('change');

                    $("#level").val(data.result.level);
                    $("#parent").val(data.result.parent);
                    $("#aktif").val(data.result.aktif);
                    // document.getElementById('batal').style.display = "block";
                    $("#tambah").html('Edit');
                    $('#action').val('edit');
                    $('#hidden_id').val(id);
                }
            })
        });

        $('#add').on('click', function() {
            $('#sample_form')[0].reset();
            $('#selectAccountDeal').val('').trigger('change');
            $('#multiple').val('').trigger('change');
            // $('#selectAccountDeal').select2('data', {id: null, text: null})
            // $('#selectAccountDeal').html('').select2({data: [{id: '', text: ''}]});
            $("#tambah").html('Tambah');
            $('#action').val('add');
            $('#hidden_id').val('');
            // document.getElementById('batal').style.display = "none";
        })

        var user_id;
        $(document).on('click', '.delete', function() {
            user_id = $(this).attr('id');
            console.log(user_id);

            if (confirm('Are you sure you want to delete this?')) {
                $.ajax({
                    url: "coa/" + user_id,
                    beforeSend: function() {
                        toastr.warning('Delete....')
                    },
                    success: function(data) {
                        $('#user_table').bootstrapTable('refresh')
                        // $('#user_table').DataTable().ajax.reload();
                        toastr.success('Berhasil');
                    }
                })
            }

            //   $('#confirmModal').modal('show');
        });

        $('#sample_form').on('submit', function(event) {
            event.preventDefault();

            // var coa = document.forms["sample_form"]["coa"].value;
            var nm_coa = document.forms["sample_form"]["nama_coa"].value;
            // var coa_par = document.forms["sample_form"]["coa_parent"].value;
            var coa_par1 = $('option:selected', '#selectAccountDeal').text();
            var level = document.forms["sample_form"]["level"].value;
            var parent = document.forms["sample_form"]["parent"].value;
            var aktif = document.forms["sample_form"]["aktif"].value;

            var ex1 = coa_par1.split("-");
            // console.log(coa_par1);
            // if (coa == "") {
            //     toastr.warning('Isi COA');
            //     return false;
            // }else 
            if (nm_coa == "") {
                toastr.warning('Isi Nama Akun');
                return false;
                // }else if(coa_par == ""){
                //     toastr.warning('Pilih COA Parent');
                //     return false;
            } else if (ex1[0] == "n") {
                toastr.warning('Pilih COA Parent');
                return false;
            } else if (level == "") {
                toastr.warning('Pilih Level');
                return false;
            } else if (parent == "") {
                toastr.warning('Pilih Parent');
                return false;
            } else if (aktif == "") {
                toastr.warning('Pilih Aktif');
                return false;
            }

            var action_url = '';

            if ($('#action').val() == 'add') {
                action_url = "coa";
            }

            if ($('#action').val() == 'edit') {
                action_url = "coa/update";
            }

            $.ajax({
                url: action_url,
                method: "POST",
                data: $(this).serialize(),
                dataType: "json",
                success: function(data) {

                    // html = '<div class="alert alert-success">' + data.success + '</div>';
                    $('#sample_form')[0].reset();
                    $('#selectAccountDeal').val('').trigger('change');
                    $("#tambah").html('Tambah');
                    $('#action').val('add');
                    $('#hidden_id').val('');
                    // document.getElementById('batal').style.display = "none";
                    // $('#user_table').DataTable().ajax.reload();
                    sele();
                    // $('#modal-default').hide();
                    // $('.modal-backdrop').remove();
                    
                    $('#user_table').bootstrapTable('refresh')
                    $('#modal-default').hide();
                    $('.modal-backdrop').remove();
                    document.querySelector("body").style.overflow = "auto";
                    
                    toastr.success('Berhasil');
                }
            });
        });
    })
</script>
@endif

@if(Request::segment(1) == 'penutupan')
<script>

    $(document).ready(function() {
        
        $('#period').on('click',function(){
            if($(this).val() == 'tgl'){
                document.getElementById("tg").style.display = "block";
                document.getElementById("bl").style.display = "none";
                document.getElementById("th").style.display = "none";
            }else if($(this).val() == 'bln'){
                document.getElementById("tg").style.display = "none";
                document.getElementById("bl").style.display = "block";
                document.getElementById("th").style.display = "none";
            }else{
                document.getElementById("tg").style.display = "none";
                document.getElementById("bl").style.display = "none";
                document.getElementById("th").style.display = "block";
            }
        })
        
        $('#periods').on('click',function(){
            if($(this).val() == 'tgl'){
                document.getElementById("tgs").style.display = "block";
                document.getElementById("bls").style.display = "none";
                document.getElementById("ths").style.display = "none";
            }else if($(this).val() == 'bln'){
                document.getElementById("tgs").style.display = "none";
                document.getElementById("bls").style.display = "block";
                document.getElementById("ths").style.display = "none";
            }else{
                document.getElementById("tgs").style.display = "none";
                document.getElementById("bls").style.display = "none";
                document.getElementById("ths").style.display = "block";
            }
        })
        

        $('input[name="daterange"]').daterangepicker({
                autoUpdateInput: false,
                locale: {
                    cancelLabel: 'Clear',
                    format: 'YYYY-MM-DD'
                }
            },
            function(start, end, label) {
                $('#daterange').val(start.format('YYYY-MM-DD') + ' - ' + end.format('YYYY-MM-DD'))
            }
        );
        
        $('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {
            $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
            $('#user_table').DataTable().destroy();
            load_data();
        });

        $('input[name="daterange"]').on('cancel.daterangepicker', function(ev, picker) {
            $(this).val('');
            $('#user_table').DataTable().destroy();
            load_data();
        });
        
        $(".goa").datepicker({
            format: "yyyy-mm",
            viewMode: "months",
            minViewMode: "months"
        });

        $('.year').datepicker({
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });
        
        function formatRibuan(angka){
            var number_string = angka.toString().replace(/[^,\d]/g, ''),
            split           = number_string.split(','),
            sisa            = split[0].length % 3,
            angka_hasil     = split[0].substr(0, sisa),
            ribuan          = split[0].substr(sisa).match(/\d{3}/gi);
     
            console.log(number_string)
     
     
            // tambahkan titik jika yang di input sudah menjadi angka ribuan
            if(ribuan){
                separator = sisa ? '.' : '';
                angka_hasil += separator + ribuan.join('.');
            }
     
            angka_hasil = split[1] != undefined ? angka_hasil + ',' + split[1] : angka_hasil;
            return angka_hasil;
        }
        
        
        $('#kert').Tabledit({
            url:'updatepen',
            deleteButton: false,
            editButton: false,
            eventType: 'dblclick',
            dataType:"json",
            columns:{
                identifier:[0, 'id'],
                editable:[ [2, 'qty']]
            },
                        
            onSuccess: function(data, textStatus) {
                var row = $('#kert').find('tr:eq('+data.id+')');
                var col =row.find("td:eq(1)").html().replace(/\./g, "");
                
                var angka = col*data.qty
                var baru = formatRibuan(angka)
                
                
                var currentRow=$('#kert').find('tr:eq('+data.id+')')
                var col1=currentRow.find("td:eq(3)").html(baru);
                
            
                var table = document.getElementById('kert');
                let total = 0
                for(let i = 1; i<table.rows.length; i++){
                    total+=Number(table.rows[i].cells[3].innerText.replace(/\./g, ""))
                    $('#inputk'+i).val(table.rows[i].cells[2].innerText)
                }
            
                var tables = document.getElementById('logs');
                let totalo = 0
                for(let i = 1; i<tables.rows.length; i++){
                    totalo+=Number(tables.rows[i].cells[3].innerText.replace(/\./g, ""))
                    // $('#inputl'+i).val(tables.rows[i].cells[2].innerText)
                }
                
                const totalInput = document.getElementById('s_fisik')
                const totalInput2 = document.getElementById('s_fisik_hide')
                totalInput.value=formatRibuan(total+totalo)
                totalInput2.value=formatRibuan(total+totalo)
                    
                    
                console.log(totalInput.value)
            
            },
        })
        
        $('#logs').Tabledit({
            url:'updatepen',
            deleteButton: false,
            editButton: false,
            eventType: 'dblclick',
            dataType:"json",
            columns:{
                identifier:[0, 'id'],
                editable:[[2, 'qty']]
            },
                        
            onSuccess: function(data, textStatus) {
                // toastr.success('Berhasil')
                console.log(data)
            
            // // $('#user_table').DataTable().ajax.reload(null, false);
            //     setTimeout(function(){
            //         $('#user_table').DataTable().ajax.reload(null, false);
            //     }, 2000);
            
                var row = $('#logs').find('tr:eq('+data.id+')');
                var col =row.find("td:eq(1)").html().replace(/\./g, "");
                
                var angka = col*data.qty
                var baru = formatRibuan(angka)
                
                
                var currentRow=$('#logs').find('tr:eq('+data.id+')')
                var col1=currentRow.find("td:eq(3)").html(baru);
                
                
            
                var table = document.getElementById('kert');
                let total = 0
                for(let i = 1; i<table.rows.length; i++){
                    total+=Number(table.rows[i].cells[3].innerText.replace(/\./g, ""))
                    // $('#inputk'+i).val(table.rows[i].cells[2].innerText)
                }
            
                var tables = document.getElementById('logs');
                let totalo = 0
                for(let i = 1; i<tables.rows.length; i++){
                    totalo+=Number(tables.rows[i].cells[3].innerText.replace(/\./g, ""))
                    $('#inputl'+i).val(tables.rows[i].cells[2].innerText)
                }
                
                
                
                
                
                
                const totalInput = document.getElementById('s_fisik')
                const totalInput2 = document.getElementById('s_fisik_hide')
                totalInput.value=formatRibuan(total+totalo)
                totalInput2.value=formatRibuan(total+totalo)
                    
                    
                console.log(totalInput.value)
            
            },
        })
    
        load_data();
        function load_data() {
            var kans = $('#kans').val();
            var pen = $('#pen').val();
            var daterange = $('#daterange').val();
            var kantor = $('#kantor').val();
            $('#user_table').DataTable({
                language: {
                    paginate: {
                        next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
                        previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>'
                    }
                },
                scrollX: true,
                serverSide: true,
                ajax: {
                    url: "penutupan",
                    data: {
                        daterange: daterange,
                        pen: pen,
                        kantor: kantor,
                        kans: kans
                    },
                },
                columns: [
                    {
                        data: 'aksi',
                        name: 'aksi'
                    },
                    {
                        data: 'tgl',
                        name: 'tgl'
                    },
                    {
                        data: 'nama_coa',
                        name: 'nama_coa'
                    },
                    {
                        data: 'saldo_akhir',
                        name: 'saldo_akhir'
                    },
                    {
                        data: 'saldo_awal',
                        name: 'saldo_awal'
                    },
                    {
                        data: 'debit',
                        name: 'debit'
                    },
                    {
                        data: 'kredit',
                        name: 'kredit'
                    },
                    {
                        data: 'adjustment',
                        name: 'adjustment'
                    },
                    {
                        data: 'coa',
                        name: 'coa'
                    },
                    {
                        data: 'user_input',
                        name: 'user_input'
                    },
                    {
                        data: 'user_update',
                        name: 'user_update'
                    },
                    
                    {
                        data: 'k100000',
                        name: 'k100000'
                    },
                    {
                        data: 'k75000',
                        name: 'k75000'
                    },
                    {
                        data: 'k50000',
                        name: 'k50000'
                    },
                    {
                        data: 'k20000',
                        name: 'k20000'
                    },
                    {
                        data: 'k10000',
                        name: 'k10000'
                    },
                    {
                        data: 'k5000',
                        name: 'k5000'
                    },
                    {
                        data: 'k2000',
                        name: 'k2000'
                    },
                    {
                        data: 'k1000',
                        name: 'k1000'
                    },
                    {
                        data: 'k500',
                        name: 'k500'
                    },
                    {
                        data: 'k100',
                        name: 'k100'
                    },
                    {
                        data: 'l1000',
                        name: 'l1000'
                    },
                    {
                        data: 'l500',
                        name: 'l500'
                    },
                    {
                        data: 'l200',
                        name: 'l200'
                    },
                    {
                        data: 'l100',
                        name: 'l100'
                    },
                    {
                        data: 'l50',
                        name: 'l50'
                    },
                    {
                        data: 'l25',
                        name: 'l25'
                    },
                ],
                order: [
                    [2, 'asc'],
                    [1, 'asc']
                ],
            });
        }
        
        $('.cek1').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });
        
        $('.cek3').on('change', function() {
            $('#user_table').DataTable().destroy();
            load_data();
        });
    });
    
    $(document).on('click', '.getdong', function() {
        var id = $(this).attr('id');
        console.log(id);
        $.ajax({
            url: "caribank/" + id,
            dataType: "json",
            success: function(data) {
                console.log(data);
                $('#id_kar_bo').val(data.user.id_karyawan);
                $('#nama_bo').val(data.user.name);
                $('#bank_bo').val(data.bank.coa);
                $('#id_kar_bo_hide').val(data.user.id_karyawan);
                $('#nama_bo_hide').val(data.user.name);
                $('#juduls').html('Bank Opename '+ data.bank.coa);
            }
        })
    })
    
    $(document).on('click', '.getdongs', function() {
        var id = $(this).attr('id');
        console.log(id);
        $.ajax({
            url: "carikantor/" + id,
            dataType: "json",
            success: function(data) {
                console.log(data);
                $('#id_kar_co').val(data.user.id_karyawan);
                $('#nama_co').val(data.user.name);
                $('#kntr_co').val(data.kantor.id_coa);
                
                $('#id_kar_co_hide').val(data.user.id_karyawan);
                $('#nama_co_hide').val(data.user.name);
                
                $('#judul').html('Cash Opename '+ data.kantor.id_coa );
            }
        })
    })
    
        $('#co_form').on('submit', function(event) {
            event.preventDefault();
    
            $.ajax({
                url: "tutupin",
                method: "POST",
                data: $(this).serialize(),
                dataType: "json",
                // beforeSend: konfir(),
                success: function(data) {
                    // var html = '';
                    // if (data.errors) {
                    //     html = '<div class="alert alert-danger">';
                    //     for (var count = 0; count < data.errors.length; count++) {
                    //         html += '<p>' + data.errors[count] + '</p>';
                    //     }
                    //     html += '</div>';
                    // }
                    // if (data.success) {
                    //     html = '<div class="alert alert-success">' + data.success + '</div>';
                        $('#co_form')[0].reset();
                        $('#modals').hide();
                        $('.modal-backdrop').remove();
                        $("body").removeClass("modal-open")
                        $('#user_table').DataTable().ajax.reload();
                    // }
                    toastr.success('Berhasil')
                }
            });
        });
        
        $('#bo_form').on('submit', function(event) {
            event.preventDefault();
    
            $.ajax({
                url: "tutupin",
                method: "POST",
                data: $(this).serialize(),
                dataType: "json",
                // beforeSend: konfir(),
                success: function(data) {
                    // var html = '';
                    // if (data.errors) {
                    //     html = '<div class="alert alert-danger">';
                    //     for (var count = 0; count < data.errors.length; count++) {
                    //         html += '<p>' + data.errors[count] + '</p>';
                    //     }
                    //     html += '</div>';
                    // }
                    // if (data.success) {
                    //     html = '<div class="alert alert-success">' + data.success + '</div>';
                        $('#bo_form')[0].reset();
                        $('#modal_aja').hide();
                        $('.modal-backdrop').remove();
                        $("body").removeClass("modal-open")
                        $('#user_table').DataTable().ajax.reload();
                    // }
                    toastr.success('Berhasil')
                }
            });
        });
    
</script>
@endif
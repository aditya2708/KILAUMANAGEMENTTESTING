@extends('template')
@section('konten')
<div class="content-body">
    <div class="container-fluid">
        
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                     <!--<form method="GET" action="{{url('')}}" >-->
                            <div class="card-body">
                                <div class="basic-form">
                                    <div class="row">
                              
                                <div class="col-lg-3 mb-3" id="tgldari">
                                    <label>Periode Dari :</label>
                                    <input type="date" class="form-control cekd" id="dari" name="dari">
                                </div>

                                <div class="col-lg-3 mb-3" id="tglke">
                                    <label>Sampai :</label>
                                    <input type="date" class="form-control cekt" id="sampai" name="sampai">
                                </div>
                                
                                
                                 <div class="col-lg-3 mb-3">
                                    <label >Unit :</label>
                                        <select class="form-control cekk" name="kntr" id="kntr">
                                            <option value=""> Semua </option>
                                            @foreach($kantor as $val)
                                            <option value="{{$val->id}}">{{$val->unit}}</option>
                                            @endforeach
                                        </select>
                                </div>
                                
                                <div class="col-lg-3 mb-3">
                                    <label>Sumber Dana</label>
                                    <select class="form-control ceks" name="sdana" id="sdana">
                                        <option value="">- Semua -</option>
                                            @foreach($sumber as $val)
                                            <option value="{{$val->id_sumber_dana}}">{{$val->sumber_dana}}</option>
                                            @endforeach
                                    </select>
                                </div>

                                
                                  <div class="pull-right" style="display: none" id="one">
                            <h3 style="float:right; margin-top:0px"><label class="badge badge-xl badge-info totaltr"></label></h3>
                            
                            <div class="pull-right"> 

                            <!--<a href="javascript:void(0)" class="btn btn-primary light filtt  mt-9" style="float:right; margin-right:15px">Adv Search</a>-->
                            </div>
                              
                            </div>
                        </div>
                        <br>
                        </div>
                      <!--</form>          -->
                </div>                
            </div>
        </div>
        
        
        
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h1 class="card-title">Resume Transaksi Dana Pengelola</h4>
                    </div>
                    
                    <div class="card-body">
                                <div class="table-responsive">
                                    <table id="user_table" class="table table-striped">
                                        <thead>
                                        <tr>
                                             <th>Program</th>
                                             <th>∑ Transaksi [T]</th>
                                             <th>∑ Quantity</th>
                                             <th>∑ Dana Pengelola [DP]</th>
                                             <th>% DP/T</th>
                                        </tr>
                                    </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        
    </div>
</div>
@endsection

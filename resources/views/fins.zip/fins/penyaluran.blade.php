@extends('template')
@section('konten')
<div class="content-body">
    <div class="container-fluid">

        <!--<div class="row page-titles">-->
        <!--    <ol class="breadcrumb">-->
        <!--        <li class="breadcrumb-item active"><a href="javascript:void(0)">FINS</a></li>-->
        <!--        <li class="breadcrumb-item"><a href="javascript:void(0)">Penyaluran</a></li>-->
        <!--    </ol>-->
        <!--</div>-->

        <!-- Modal -->
        <div class="modal fade" id="modal-default1">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel">Entry Penyaluran</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        </button>
                    </div>
                    <form class="form-horizontal" method="post" id="sample_form">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <h3 style="margin-top: -10px">Informasi PM</h3>
                                            <hr style="margin: 0px; margin-bottom: 10px">

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Nama PM :</label>
                                                        <div class="col-md-7">
                                                            <select required class="select2" style="width: 100%;" name="nama_pm" id="nama_pm" type="text">
                                                                <option value="">- Pilih PM -</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" id="idpm" name="idpm">

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">HP :</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control " name="hppm" id="hppm" value="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Email :</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control " name="emailpm" id="emailpm" value="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Alamat :</label>
                                                        <div class="col-md-7">
                                                            <textarea class="form-control" name="alamat_pm" id="alamat_pm"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Koordinat :</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="koordinat_pm" id="koordinat_pm" value="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Asnaf :</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control input-sm" name="asnaf" id="asnaf" value="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">PJ :</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="pj" id="pj" value="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Kantor :</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control " name="kantor_pm" id="kantor_pm" value="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>

                                <div class="col-md-7">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <h3 style="margin-top: -10px">Informasi Penyaluran</h3>
                                            <hr style="margin: 0px; margin-bottom: 10px">

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Permohonan Via :</label>
                                                        <div class="col-md-7">
                                                            <select required class="form-control input-sm" style="width: 100%;" name="via_per" id="via_per">
                                                                <option value="">- Pilih -</option>
                                                                <option value="datang">Datang Langsung</option>
                                                                <option value="email">Email</option>
                                                                <option value="pos">Pos</option>
                                                                <option value="fax">Fax</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">User Insert :</label>
                                                        <div class="col-md-7">
                                                            <text id="user_input" name="user_input">{{ Auth::user()->name }}</text>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Pencairan Via :</label>
                                                        <div class="col-md-7">
                                                            <select required class="form-control input-sm" style="width: 100%;" name="via_cair" id="via_cair">
                                                                <option value="">- Pilih -</option>
                                                                <option value="cash">Cash</option>
                                                                <option value="bank">Bank</option>
                                                                <option value="noncash">Non Cash</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">

                                                    <div class="row" hidden id="bank_hide">
                                                        <label class="col-sm-5">Bank :</label>
                                                        <div class="col-md-7">
                                                            <select class="form-control input-sm" style="width: 100%;" name="bank" id="bank">
                                                                <option value="">- Pilih -</option>
                                                                @foreach($bank as $val)
                                                                <option value="{{$val->id_bank}}" data-value="{{$val->nama_bank}}">{{$val->nama_bank}} {{$val->no_rek}}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="row" hidden id="noncash_hide">
                                                        <label class="col-sm-5">Non Cash :</label>
                                                        <div class="col-md-7">
                                                            <select class="js-example-basic-singlex" style="width: 100%;" name="non_cash" id="non_cash">
                                                                <option value="">- Pilih -</option>

                                                            </select>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Kantor :</label>
                                                        <div class="col-md-7">
                                                            <select required class="form-control input-sm" style="width: 100%;" name="kantor" id="kantor">
                                                                <option value="">- Pilih -</option>
                                                                @foreach($kantor as $val)
                                                                <option value="{{$val->id}}" data-value="{{$val->unit}}">{{$val->unit}}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Tanggal Permohonan :</label>
                                                        <div class="col-md-7">
                                                            <!--<text>{{ date('Y-m-d H:i:s') }}</text>-->
                                                            <input type="date" class="form-control" id="tgl_per" name="tgl_per">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row form-group">

                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <label class="col-sm-5">Tanggal Salur : </label>
                                                        <div class="col-md-7">
                                                            <!--<text>{{ date('Y-m-d H:i:s') }}</text>-->
                                                            <input type="date" class="form-control" id="tgl_now" name="tgl_now">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>

                                <div class="col-md-12 ">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <h3 style="margin-top: -10px">Detail Penyaluran</h3>
                                            <hr style="margin: 0px; margin-bottom: 10px">
                                            <div class="row mt-3">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="">Jenis Transaksi :</label>
                                                            <select class="js-example-basic-single" style="width: 100%;" name="jenis_t" id="jenis_t">
                                                                <option value="">Pilih Jenis Transaksi</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 mb-3">
                                                            <label for="">Qty :</label>
                                                            <input type="text" min="0.0" name="qty" id="qty" class="form-control form-control-sm">
                                                        </div>
                                                        <div class="col-md-3 mb-3">
                                                            <label for="">Nominal :</label>
                                                            <input type="text" min="0.0" name="nominal" id="nominal" onkeyup="rupiah(this);" class="form-control form-control-sm">
                                                        </div>

                                                        <div class="col-md-3 mb-3">
                                                            <label for="">total :</label>
                                                            <input type="text" min="0.0" name="total" id="total" onkeyup="rupiah(this);" class="form-control form-control-sm">
                                                        </div>

                                                        <div class="col-md-5 mb-3">
                                                            <label for="">Keterangan :</label>
                                                            <input type="text" name="ket" id="ket" class="form-control form-control-sm">
                                                        </div>

                                                        <div class="col-md-1 mb-3">
                                                            <label>&nbsp;</label>
                                                            <a id="add" class="btn btn-primary"><i class="fa fa-plus"></i></a>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-md-12">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <div class="table-responsive">
                                                <table id="user_table_1" class="table table-bordered ">
                                                    <thead>
                                                        <tr>
                                                            <!--<th>COA</th>-->
                                                            <th>Jenis Transaksi</th>
                                                            <th>Qty</th>
                                                            <th>Nominal</th>
                                                            <th>Total</th>
                                                            <th>Keterangan</th>
                                                            <th>Kantor</th>
                                                            <th>Aksi</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody id="table">

                                                    </tbody>
                                                    <tfoot id="foot">

                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-primary" id="smpn" disabled>Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- End Modal -->

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"></h4>
                        <div class="pull-right">
                            <!--<a href="#" class="btn btn-dark rounded-lg " id="taki" style=" margin-right: 20px;">Adv Search</a>-->
                            <!--<button type="button" id="tambah" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modal-default1" style="float:left; margin-left:5px"><i class="fa fa-plus"></i>&nbsp Tambah</button>-->
                            <button type="button" id="tambah" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modal-default1"><span class="btn-icon-start text-primary"><i class="fa fa-plus color-primary"></i></span>Entry Penyaluran</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive"><input type="hidden" id="advsrc" value="tutup">
                            <table id="user_table" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th class="cari">Penerima Manfaat</th>
                                        <th class="cari">Program</th>
                                        <th class="cari">Nominal</th>
                                        <!--<th hidden></th>-->
                                        <th class="cari">Tgl Mohon</th>
                                        <th class="cari">Tgl Salur</th>
                                        <th class="cari">Kantor Salur</th>
                                        <!--<th class="cari">Referensi</th>-->
                                        <!--<th class="cari">Program</th>-->
                                        <!--<th>Kantor</th>-->
                                        <th hidden>created_at</th>
                                        <!--<th>COA Debet</th>-->
                                        <!--<th>COA Kredit</th>-->
                                        <!--<th>Acc</th>-->

                                    </tr>
                                </thead>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@extends('template')
@section('konten')
<div class="content-body">
    <div class="container-fluid">

        <!--<div class="row page-titles">-->
        <!--    <ol class="breadcrumb">-->
        <!--        <li class="breadcrumb-item active"><a href="javascript:void(0)">FINS</a></li>-->
        <!--        <li class="breadcrumb-item"><a href="javascript:void(0)">Gaji Karyawan</a></li>-->
        <!--    </ol>-->
        <!--</div>-->
        
        <!--Modal-->
        <div class="modal fade" id="eksdata" >
            <div class="modal-dialog modal-dialog-centered" role="document">
                <form method="get" action="{{url('eksportdata')}}">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Eksport Data</h5>
                        </div>
                        <div class="modal-body">

                            @csrf
                            <div class="row">
                                <div class="col-lg-4">
                                    <label>Pilih Bulan</label>
                                    <div class="form-group">
                                        <input type="text" name="tgl" id="tgl" class="form-control cobain" placeholder="diisi ya.." autocomplete="off" required>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <label>Pilih Unit</label>
                                    <div class="form-group">
                                        <select name="unit" id="unit" class="form-control">
                                            <option value="">Semua Unit Kerja</option>
                                            @foreach($kntr as $k)
                                            <option value="{{$k->id}}">{{$k->unit}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <label>Pilih Status Kerja</label>
                                    <div class="form-group">
                                        <select class="form-control" name="status" id="status">
                                            <option value="">Semua Status Kerja</option>
                                            <option value="Contract">Contract</option>
                                            <option value="Training">Training</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Eksport</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="modal fade" id="ekspay" >
            <div class="modal-dialog modal-dialog-centered" role="document">
                <form method="get" action="{{url('eksportpay')}}">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Eksport Payroll</h5>
                        </div>
                        <div class="modal-body">
                            @csrf
                            <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <label>Pilih Tanggal</label>
                                    <div class="form-group">
                                        <input type="text" name="tgl" id="tgl" class="form-control daterange" placeholder="{{ date('m-Y') }}" autocomplete="off" required>
                                    </div>
                                </div>

                                <div class="col-lg-4 mb-3">
                                    <label>Pilih Unit</label>
                                    <div class="form-group">
                                        <select name="unit" class="form-control" id="unit">
                                            <!--<option value="">-- Pilih Unit kerja--</option>-->
                                            <option value="">Semua Unit Kerja</option>
                                            @foreach($kntr as $k)
                                            <option value="{{$k->id}}">{{$k->unit}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-4 mb-3">
                                    <label>Pilih Status Kerja</label>
                                    <div class="form-group">
                                        <select class="form-control" name="status" id="status">
                                            <!--<option value="">-- Pilih Status Kerja</option>-->
                                            <option value="">Semua Status</option>
                                            <option value="Contract">Contract</option>
                                            <option value="Training">Training</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" id="ezz">Eksport</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="modal fade" id="eksbpjs" >
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <form method="get" action="{{url('eksportbpjs')}}">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Eksport BPJS</h5>
                        </div>
                        <div class="modal-body">
                            @csrf
                            <div class="row">
                                <div class="col-md-3">
                                    <label>Pilih Tanggal</label>
                                    <div class="form-group">
                                        <input type="text" name="tgl" id="tgl" class="form-control daterange" required="required" placeholder="{{ date('m-Y') }}" autocomplete="off" required>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <label>Pilih BPJS</label>
                                    <div class="form-group">
                                        <select required="required" name="bpjs" id="bpjs" class="form-control">
                                            <!--<option selected disabled>-- Pilih BPJS --</option>-->
                                            <option value="kesehatan">Kesehatan</option>
                                            <option value="ketenagakerjaan">Ketenagakerjaan</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <label>Pilih Unit</label>
                                    <div class="form-group">
                                        <select name="unit" id="unit" class="form-control">
                                            <!--<option>-- Pilih Unit --</option>-->
                                            <option value="">Semua Unit Kerja</option>
                                            @foreach($kntr as $k)
                                            <option value="{{$k->id}}">{{$k->unit}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>



                                <div class="col-md-3">
                                    <label>Pilih Status Kerja</label>
                                    <div class="form-group">
                                        <select class="form-control" name="status" id="status">
                                            <!--<option>-- Pilih Status Kerja</option>-->
                                            <option value="">Semua Status Kerja</option>
                                            <option value="Contract">Contract</option>
                                            <option value="Training">Training</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Eksport</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- End Modal -->

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <!--Gaji Karyawan-->
                        <h4 class="title-header"></h4>
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-rounded btn-success" id="eksd" data-bs-toggle="modal" data-bs-target="#eksdata" style="margin-right: 10px"><span class="btn-icon-start text-success"><i class="fa fa-download  color-success"></i></span>Ekspor Data(Gaji)</button>
                            @if(Auth::user()->level == 'admin' || Auth::user()->keuangan == 'keuangan pusat')
                            <button type="button" class="btn btn-rounded btn-info" id="eksp" data-bs-toggle="modal" data-bs-target="#ekspay" style="margin-right: 10px"><span class="btn-icon-start text-info"><i class="fa fa-download  color-info"></i></span>Ekspor Payroll</button>
                            <button type="button" class="btn btn-rounded btn-warning" id="eksb" data-bs-toggle="modal" data-bs-target="#eksbpjs"><span class="btn-icon-start text-warning"><i class="fa fa-download  color-warning"></i></span>Ekspor BPJS</button>
                            @endif
                            <!--<a href="#" id="eksd" data-bs-toggle="modal" data-bs-target="#eksdata" class="btn btn-success btn-xs">Eksport Data</a>-->
                            <!--<a href="#" id="eksp" data-bs-toggle="modal" data-bs-target="#ekspay" class="btn btn-info btn-xs">Eksport Payroll</a>-->
                            <!--<a href="#" id="eksb" data-bs-toggle="modal" data-bs-target="#eksbpjs" class="btn btn-warning btn-xs">Eksport BPJS</a>-->
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="basic-form">
                                    <div class="row">
                                        <form method="GET">
                                            <div class="col-lg-12">
                                                <div class="row">
                                                    <div class="col-lg-3 mb-3">
                                                        <label>Bulan dan Tahun</label>
                                                        <input type="text" class="form-control cek" name="bln" id="bln" placeholder="contoh {{date('m-Y') }}">
                                                    </div>
                                                    <div class="col-lg-2 mb-3">
                                                        <label>Jabatan</label>
                                                        <select id="jab" class="form-control cek1" name="jab">
                                                            <option value="">Tidak Ada</option>
                                                            @foreach($jabat as $j)
                                                            <option value="{{$j->id}}">{{$j->jabatan}}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="col-lg-2 mb-3">
                                                        <label>Kantor</label>
                                                        <select id="kan" class="form-control cek2" name="kan">
                                                            <option value="">Tidak Ada</option>
                                                            @foreach($kntr as $k)
                                                            <option value="{{$k->id}}">{{$k->unit}}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="col-lg-2 mb-2">
                                                        <a href="javascript:void(0)" class="btn btn-danger btn-sm reset" style="margin-top:25px">Reset Filter</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <div class="table-responsive">
                                    <table id="user_table" class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <th>Nama</th>
                                                <th>Jabatan</th>
                                                <th>Kantor</th>
                                                <th>Gaji Pokok</th>
                                                <th>Tunjangan Jabatan</th>
                                                <th>Tunjangan Daerah</th>
                                                <th>Tunjangan Anak</th>
                                                <th>Tunjangan Pasangan</th>
                                                <th>Tunjangan Beras</th>
                                                <th>Transport</th>
                                                <th>Jumlah Hari</th>
                                                <th>Total</th>
                                                <!--<th>Aksi</th>-->
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
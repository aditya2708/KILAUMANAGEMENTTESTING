@extends('template')
@section('konten')
<div class="content-body">
    <div class="container-fluid">

        <!--<div class="row page-titles">-->
        <!--    <ol class="breadcrumb">-->
        <!--        <li class="breadcrumb-item active"><a href="javascript:void(0)">FINS</a></li>-->
        <!--        <li class="breadcrumb-item"><a href="javascript:void(0)">Chart of Account</a></li>-->
        <!--    </ol>-->
        <!--</div>-->

        <!-- Modal -->
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <h4 class="modal-title" id="title"></h4>
                    </div>
                    <form class="form-horizontal" id="sample_form" method="post">
                        <div class="modal-body">
                            <div class="basic-form">
                                <div class="row mb-3">
                                    <label for="" class="col-sm-4">Nama Akun :</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control input-sm" name="nama_coa" id="nama_coa">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="" class="col-sm-4">COA Parent :</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="selectAccountDeal" style="width: 100%;" name="id_parent" id="id_parent">
                                            <option></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-4">Grup</label>
                                    <div class="col-sm-8">
                                        <select class="form-control select2" multiple="multiple" data-placeholder="Select a State" name="group[]" id="multiple" style="width: 100%;">
                                            @foreach($group as $val)
                                            <option value="{{$val->id}}">{{$val->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="" class="col-md-4">Level :</label>
                                    <div class="col-sm-8">
                                        <select class="form-control input-sm" name="level" id="level">
                                            <option value="">- Pilih Level -</option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="" class="col-md-4">Parent :</label>
                                    <div class="col-sm-8">
                                        <select class="form-control input-sm" name="parent" id="parent">
                                            <option value="">- Pilih -</option>
                                            <option value="y">Parent</option>
                                            <option value="n">Child</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="" class="col-md-4">Aktif :</label>
                                    <div class="col-sm-8">
                                        <select class="form-control input-sm" name="aktif" id="aktif">
                                            <option value="">- Pilih -</option>
                                            <option value="y">Ya</option>
                                            <option value="n">Tidak</option>
                                        </select>
                                    </div>
                                </div>
                                <input type="hidden" name="coa_parent" id="coa_parent" />
                                <input type="hidden" name="hidden_id" id="hidden_id" />
                                <input type="hidden" name="action" id="action" value="add" />
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- End Modal -->

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Chart of Account</h4>
                        <div class="pull-right">
                        <button type="button" id="add" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modal-default">Tambah</button>
                        </div>
                    </div>

                    <div class="card-body">
                        <!--<div class="table-responsive">-->
                        <input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Cari Program..." style="float: right; margin-top : 10px; margin-left: 10px; width: 20%; height: 2.5rem">
                            <table id="user_table" class="table  table-striped">

                            </table>
                        <!--</div>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
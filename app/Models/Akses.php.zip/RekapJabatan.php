<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RekapJabatan extends Model
{
    protected $table ="rekap_jabatan";
    protected $primaryKey = "id_rekjab";
    protected $fillable = [
        'id_karyawan', 'nama', 'id_jabatan', 'id_spv', 'tgl_jab', 'file','user_insert',
    ];
}

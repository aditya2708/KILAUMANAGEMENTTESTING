<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RequestKar extends Model
{
    protected $table ="request";

    protected $fillable = [
     'id_request', 'id_karyawan', 'pr_jabatan', 'kantor_induk', 'nama', 'status', 'lampiran', 'foto', 'acc', 'latitude', 'longitude', 'tg_mulai', 'tg_akhir', 'id_presensi', 'user_update', 'alasan',
     'id_shift', 'shift'
    ];
    
    protected $primaryKey = 'id_request';
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Jenreq extends Model
{
    protected $table ="jenreq";
	protected $primaryKey = 'id';
    protected $fillable = [
     'jenis', 'pres', 'izin', 'id_com', 'lam', 'lok', 'foto'
 ];
}
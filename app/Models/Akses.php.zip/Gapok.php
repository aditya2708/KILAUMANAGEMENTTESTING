<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gapok extends Model
{
    protected $table ="gapok";
	protected $primaryKey = 'id_gapok';
    protected $fillable = [
     'th', 'IA','IB','IC','ID','IIA','IIB','IIC','IID','IIE','IIIA','IIIB','IIIC','IIID'
 ];
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MutasiKaryawan extends Model
{
    protected $table ="mutasi_karyawan";

    protected $fillable = [
     'id_karyawan', 'kantor_asal', 'kantor_baru', 'file_sk', 'tgl_mutasi', 'durasi', 'user_insert'
    ];
    
    protected $primaryKey = 'id_mutasi';
}

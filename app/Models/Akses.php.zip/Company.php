<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    protected $table ="company";
	protected $primaryKey = 'id_com';
    protected $fillable = [
     'id_hc', 'id_karyawan', 'name', 'user_insert', 'user_update'
 ];
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
    protected $table ="company";
    protected $primaryKey = 'id_com';
    protected $fillable = [
     'id_hc', 'level_hc', 'id_karyawan', 'name', 'direktur','alias', 'npwp', 'sms','wa','sk','email','web','berdiri','alamat','akses','jenis','logo','ttd','jkk','jkm','jht','jpn','kesehatan','gaji','title','des','no_telp','jumlah_karyawan', 'user_insert', 'user_update'
 ];
}
